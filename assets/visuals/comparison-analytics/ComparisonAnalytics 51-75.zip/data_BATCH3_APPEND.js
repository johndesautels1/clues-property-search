// =============================================================================
// APPEND TO data.js - ADD THESE FIELDS TO EACH PROPERTY OBJECT
// BATCH 3: CATEGORIES 11-15
// CONVERSATION ID: PROPERTY-VIZ-SESSION-001
// =============================================================================

// FOR PROPERTY A - Add after Category 10 (exterior):

    // CATEGORY 11: LOCATION SCORES
    locationScores: {
        walkScore: 14,
        walkScoreDesc: "Car-Dependent",
        transitScore: 18,
        transitScoreDesc: "Minimal Transit",
        bikeScore: 28,
        bikeScoreDesc: "Bikeable",
        mobilityScoreAvg: 20,
        walkabilityDesc: "Suburban, car required",
        publicTransitAccess: "PSTA Bus (limited)",
        commuteToCity: 25,
        noiseLevel: "Low",
        trafficLevel: "Low",
        elevation: 42
    },

    // CATEGORY 12: SCHOOLS
    schools: {
        districtName: "Pinellas County",
        elementarySchool: "Seminole Elementary",
        elementaryRating: 6,
        elementaryDistance: 0.8,
        middleSchool: "Seminole Middle",
        middleRating: 5,
        middleDistance: 1.4,
        highSchool: "Seminole High",
        highRating: 6,
        highDistance: 2.1,
        avgSchoolRating: 5.7,
        nearestSchoolDistance: 0.8
    },

    // CATEGORY 13: DISTANCES & AMENITIES
    distances: {
        toGrocery: 1.2,
        toHospital: 1.2,
        toAirport: 22,
        toPark: 0.8,
        toBeach: 4.2,
        toEmergencyServices: 1.1,
        essentialServicesAvg: 1.17,
        lifestyleAmenitiesAvg: 9.0
    },

    // CATEGORY 14: SAFETY & CRIME
    safety: {
        neighborhoodSafetyRating: "B",
        safetyScore: 72,
        violentCrimeIndex: 18,
        propertyCrimeIndex: 45,
        combinedCrimeIndex: 31.5,
        crimeDesc: "Well Below Average"
    },

    // CATEGORY 15: COMMUNITY & HOA
    community: {
        hasHOA: false,
        hoaName: null,
        hoaFeeAnnual: 0,
        hoaIncludes: null,
        ownershipType: "Fee Simple",
        petPolicy: "No Restrictions",
        petSizeLimit: null,
        maxPetWeight: null,
        ageRestrictions: "None",
        hasGated: false,
        hasCommunityPool: false,
        hasClubhouse: false,
        hasFitnessCenter: false,
        hasTennisCourts: false,
        hasBeachAccess: false,
        hasDogPark: false,
        communityAmenityCount: 0
    }

// =============================================================================

// FOR PROPERTY B - Add after Category 10 (exterior):

    // CATEGORY 11: LOCATION SCORES
    locationScores: {
        walkScore: 72,
        walkScoreDesc: "Very Walkable",
        transitScore: 45,
        transitScoreDesc: "Some Transit",
        bikeScore: 68,
        bikeScoreDesc: "Bikeable",
        mobilityScoreAvg: 62,
        walkabilityDesc: "Beach town, walkable to shops",
        publicTransitAccess: "PSTA Bus + Beach Trolley",
        commuteToCity: 18,
        noiseLevel: "Moderate",
        trafficLevel: "Moderate-High",
        elevation: 8
    },

    // CATEGORY 12: SCHOOLS
    schools: {
        districtName: "Pinellas County",
        elementarySchool: "Gulf Beaches Elementary",
        elementaryRating: 7,
        elementaryDistance: 1.2,
        middleSchool: "Azalea Middle",
        middleRating: 7,
        middleDistance: 2.8,
        highSchool: "Boca Ciega High",
        highRating: 5,
        highDistance: 4.2,
        avgSchoolRating: 6.3,
        nearestSchoolDistance: 1.2
    },

    // CATEGORY 13: DISTANCES & AMENITIES
    distances: {
        toGrocery: 1.8,
        toHospital: 3.4,
        toAirport: 18,
        toPark: 0.1,
        toBeach: 0.0,
        toEmergencyServices: 2.2,
        essentialServicesAvg: 2.47,
        lifestyleAmenitiesAvg: 6.03
    },

    // CATEGORY 14: SAFETY & CRIME
    safety: {
        neighborhoodSafetyRating: "A-",
        safetyScore: 85,
        violentCrimeIndex: 22,
        propertyCrimeIndex: 38,
        combinedCrimeIndex: 30.0,
        crimeDesc: "Well Below Average"
    },

    // CATEGORY 15: COMMUNITY & HOA
    community: {
        hasHOA: true,
        hoaName: "Gulf Towers COA",
        hoaFeeAnnual: 8400,
        hoaIncludes: "Water, Trash, Cable, Insurance, Pool, Exterior, Reserves",
        ownershipType: "Condominium",
        petPolicy: "2 pets, 25 lbs max",
        petSizeLimit: "25 lbs",
        maxPetWeight: 25,
        ageRestrictions: "None",
        hasGated: true,
        hasCommunityPool: true,
        hasClubhouse: true,
        hasFitnessCenter: true,
        hasTennisCourts: true,
        hasBeachAccess: true,
        hasDogPark: false,
        communityAmenityCount: 6
    }

// =============================================================================

// FOR PROPERTY C - Add after Category 10 (exterior):

    // CATEGORY 11: LOCATION SCORES
    locationScores: {
        walkScore: 22,
        walkScoreDesc: "Car-Dependent",
        transitScore: 21,
        transitScoreDesc: "Minimal Transit",
        bikeScore: 35,
        bikeScoreDesc: "Bikeable",
        mobilityScoreAvg: 26,
        walkabilityDesc: "Suburban residential",
        publicTransitAccess: "PSTA Bus (limited)",
        commuteToCity: 22,
        noiseLevel: "Low",
        trafficLevel: "Low",
        elevation: 12
    },

    // CATEGORY 12: SCHOOLS
    schools: {
        districtName: "Pinellas County",
        elementarySchool: "Ridgecrest Elementary",
        elementaryRating: 8,
        elementaryDistance: 1.1,
        middleSchool: "Largo Middle",
        middleRating: 6,
        middleDistance: 0.9,
        highSchool: "Largo High",
        highRating: 7,
        highDistance: 1.8,
        avgSchoolRating: 7.0,
        nearestSchoolDistance: 0.9
    },

    // CATEGORY 13: DISTANCES & AMENITIES
    distances: {
        toGrocery: 1.5,
        toHospital: 2.8,
        toAirport: 20,
        toPark: 0.6,
        toBeach: 3.8,
        toEmergencyServices: 1.8,
        essentialServicesAvg: 2.03,
        lifestyleAmenitiesAvg: 8.13
    },

    // CATEGORY 14: SAFETY & CRIME
    safety: {
        neighborhoodSafetyRating: "B+",
        safetyScore: 78,
        violentCrimeIndex: 20,
        propertyCrimeIndex: 42,
        combinedCrimeIndex: 31.0,
        crimeDesc: "Well Below Average"
    },

    // CATEGORY 15: COMMUNITY & HOA
    community: {
        hasHOA: true,
        hoaName: "Bayshore Estates HOA",
        hoaFeeAnnual: 1200,
        hoaIncludes: "Lawn, Gate, Common Areas",
        ownershipType: "Fee Simple",
        petPolicy: "2 pets, 40 lbs max",
        petSizeLimit: "40 lbs",
        maxPetWeight: 40,
        ageRestrictions: "55+ (Owner only)",
        hasGated: true,
        hasCommunityPool: true,
        hasClubhouse: true,
        hasFitnessCenter: false,
        hasTennisCourts: false,
        hasBeachAccess: false,
        hasDogPark: true,
        communityAmenityCount: 4
    }
