// =============================================================================
// BATCH 3: APPEND THESE FUNCTIONS TO YOUR EXISTING app.js
// CATEGORY 11-15: CHARTS 51-75
// CONVERSATION ID: PROPERTY-VIZ-SESSION-001
// =============================================================================

// =============================================================================
// CATEGORY 11: LOCATION SCORES (Charts 51-55)
// =============================================================================

// Chart 11.1 - Walk Score Comparison
function createChart_11_1() {
    const ctx = document.getElementById('chart_11_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Walk Score',
                data: properties.map(p => p.locationScores.walkScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: context => {
                            const prop = properties[context.dataIndex];
                            return prop.locationScores.walkScoreDesc;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: value => value + '/100'
                    }
                }
            }
        }
    });
}

// Chart 11.2 - Transit Score Analysis
function createChart_11_2() {
    const ctx = document.getElementById('chart_11_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Transit Score',
                data: properties.map(p => p.locationScores.transitScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: context => {
                            const prop = properties[context.dataIndex];
                            return prop.locationScores.transitScoreDesc;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: value => value + '/100'
                    }
                }
            }
        }
    });
}

// Chart 11.3 - Bike Score Comparison
function createChart_11_3() {
    const ctx = document.getElementById('chart_11_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Bike Score',
                data: properties.map(p => p.locationScores.bikeScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: context => {
                            const prop = properties[context.dataIndex];
                            return prop.locationScores.bikeScoreDesc;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: value => value + '/100'
                    }
                }
            }
        }
    });
}

// Chart 11.4 - Mobility Score Radar
function createChart_11_4() {
    const ctx = document.getElementById('chart_11_4');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Walk Score', 'Transit Score', 'Bike Score'],
            datasets: properties.map(p => ({
                label: p.name,
                data: [
                    p.locationScores.walkScore,
                    p.locationScores.transitScore,
                    p.locationScores.bikeScore
                ],
                backgroundColor: p.color + '40',
                borderColor: p.color,
                borderWidth: 2,
                pointBackgroundColor: p.color,
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: p.color
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        stepSize: 20
                    }
                }
            }
        }
    });
}

// Chart 11.5 - Noise & Traffic Analysis
function createChart_11_5() {
    const ctx = document.getElementById('chart_11_5');
    const levelScore = {
        'Low': 1,
        'Moderate': 2,
        'Moderate-High': 3,
        'High': 4
    };
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Noise Level',
                    data: properties.map(p => levelScore[p.locationScores.noiseLevel] || 1),
                    backgroundColor: '#d4af37'
                },
                {
                    label: 'Traffic Level',
                    data: properties.map(p => levelScore[p.locationScores.trafficLevel] || 1),
                    backgroundColor: '#4a9eff'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 4,
                    ticks: {
                        stepSize: 1,
                        callback: value => {
                            const labels = ['', 'Low', 'Moderate', 'Mod-High', 'High'];
                            return labels[value] || '';
                        }
                    }
                }
            }
        }
    });
}

// =============================================================================
// CATEGORY 12: SCHOOLS (Charts 56-60)
// =============================================================================

// Chart 12.1 - School Ratings Comparison
function createChart_12_1() {
    const ctx = document.getElementById('chart_12_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Elementary',
                    data: properties.map(p => p.schools.elementaryRating),
                    backgroundColor: '#d4af37'
                },
                {
                    label: 'Middle',
                    data: properties.map(p => p.schools.middleRating),
                    backgroundColor: '#4a9eff'
                },
                {
                    label: 'High School',
                    data: properties.map(p => p.schools.highRating),
                    backgroundColor: '#b76e79'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10,
                    ticks: {
                        stepSize: 1,
                        callback: value => value + '/10'
                    }
                }
            }
        }
    });
}

// Chart 12.2 - School Distance Analysis
function createChart_12_2() {
    const ctx = document.getElementById('chart_12_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Elementary',
                    data: properties.map(p => p.schools.elementaryDistance),
                    backgroundColor: '#d4af37'
                },
                {
                    label: 'Middle',
                    data: properties.map(p => p.schools.middleDistance),
                    backgroundColor: '#4a9eff'
                },
                {
                    label: 'High School',
                    data: properties.map(p => p.schools.highDistance),
                    backgroundColor: '#b76e79'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' mi'
                    }
                }
            }
        }
    });
}

// Chart 12.3 - Average School Rating
function createChart_12_3() {
    const ctx = document.getElementById('chart_12_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Average School Rating',
                data: properties.map(p => p.schools.avgSchoolRating),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10,
                    ticks: {
                        stepSize: 1,
                        callback: value => value + '/10'
                    }
                }
            }
        }
    });
}

// Chart 12.4 - Nearest School Distance
function createChart_12_4() {
    const ctx = document.getElementById('chart_12_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Distance to Nearest School',
                data: properties.map(p => p.schools.nearestSchoolDistance),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' miles'
                    }
                }
            }
        }
    });
}

// Chart 12.5 - School District Quality
function createChart_12_5() {
    const ctx = document.getElementById('chart_12_5');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name + ' (' + p.schools.avgSchoolRating.toFixed(1) + '/10)'),
            datasets: [{
                data: properties.map(p => p.schools.avgSchoolRating),
                backgroundColor: properties.map(p => p.color),
                borderWidth: 2,
                borderColor: '#1a1f2e'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: context => {
                            const prop = properties[context.dataIndex];
                            return prop.schools.districtName + ': ' + context.parsed.toFixed(1) + '/10';
                        }
                    }
                }
            }
        }
    });
}

// =============================================================================
// CATEGORY 13: DISTANCES & AMENITIES (Charts 61-65)
// =============================================================================

// Chart 13.1 - Essential Services Proximity
function createChart_13_1() {
    const ctx = document.getElementById('chart_13_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Grocery',
                    data: properties.map(p => p.distances.toGrocery),
                    backgroundColor: '#d4af37'
                },
                {
                    label: 'Hospital',
                    data: properties.map(p => p.distances.toHospital),
                    backgroundColor: '#4a9eff'
                },
                {
                    label: 'Airport',
                    data: properties.map(p => p.distances.toAirport),
                    backgroundColor: '#b76e79'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' mi'
                    }
                }
            }
        }
    });
}

// Chart 13.2 - Lifestyle Amenities Distance
function createChart_13_2() {
    const ctx = document.getElementById('chart_13_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Park',
                    data: properties.map(p => p.distances.toPark),
                    backgroundColor: '#2ecc71'
                },
                {
                    label: 'Beach',
                    data: properties.map(p => p.distances.toBeach),
                    backgroundColor: '#3498db'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' mi'
                    }
                }
            }
        }
    });
}

// Chart 13.3 - Emergency Services Distance
function createChart_13_3() {
    const ctx = document.getElementById('chart_13_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Emergency Services',
                data: properties.map(p => p.distances.toEmergencyServices),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' miles'
                    }
                }
            }
        }
    });
}

// Chart 13.4 - Distance Radar Chart
function createChart_13_4() {
    const ctx = document.getElementById('chart_13_4');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Grocery', 'Hospital', 'Park', 'Beach', 'Emergency'],
            datasets: properties.map(p => ({
                label: p.name,
                data: [
                    p.distances.toGrocery,
                    p.distances.toHospital,
                    p.distances.toPark,
                    p.distances.toBeach,
                    p.distances.toEmergencyServices
                ],
                backgroundColor: p.color + '40',
                borderColor: p.color,
                borderWidth: 2,
                pointBackgroundColor: p.color,
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: p.color
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' mi'
                    },
                    reverse: true  // Lower is better for distances
                }
            }
        }
    });
}

// Chart 13.5 - Average Distance Comparison
function createChart_13_5() {
    const ctx = document.getElementById('chart_13_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Essential Services Avg',
                    data: properties.map(p => p.distances.essentialServicesAvg),
                    backgroundColor: '#d4af37'
                },
                {
                    label: 'Lifestyle Amenities Avg',
                    data: properties.map(p => p.distances.lifestyleAmenitiesAvg),
                    backgroundColor: '#4a9eff'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' mi'
                    }
                }
            }
        }
    });
}

// =============================================================================
// CATEGORY 14: SAFETY & CRIME (Charts 66-70)
// =============================================================================

// Chart 14.1 - Safety Rating Comparison
function createChart_14_1() {
    const ctx = document.getElementById('chart_14_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Safety Score',
                data: properties.map(p => p.safety.safetyScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: context => {
                            const prop = properties[context.dataIndex];
                            return 'Grade: ' + prop.safety.neighborhoodSafetyRating;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: value => value + '/100'
                    }
                }
            }
        }
    });
}

// Chart 14.2 - Crime Index Analysis
function createChart_14_2() {
    const ctx = document.getElementById('chart_14_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Violent Crime',
                    data: properties.map(p => p.safety.violentCrimeIndex),
                    backgroundColor: '#e74c3c'
                },
                {
                    label: 'Property Crime',
                    data: properties.map(p => p.safety.propertyCrimeIndex),
                    backgroundColor: '#f39c12'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    callbacks: {
                        footer: () => 'Lower is better (National avg = 100)'
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' (100=avg)'
                    }
                }
            }
        }
    });
}

// Chart 14.3 - Safety Score Gauge
function createChart_14_3() {
    const ctx = document.getElementById('chart_14_3');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name + ' (' + p.safety.neighborhoodSafetyRating + ')'),
            datasets: [{
                data: properties.map(p => p.safety.safetyScore),
                backgroundColor: properties.map(p => p.color),
                borderWidth: 2,
                borderColor: '#1a1f2e'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            circumference: 180,
            rotation: 270,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: context => {
                            const prop = properties[context.dataIndex];
                            return prop.safety.neighborhoodSafetyRating + ': ' + context.parsed + '/100';
                        }
                    }
                }
            }
        }
    });
}

// Chart 14.4 - Crime vs National Average
function createChart_14_4() {
    const ctx = document.getElementById('chart_14_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Combined Crime Index',
                    data: properties.map(p => p.safety.combinedCrimeIndex),
                    backgroundColor: properties.map(p => p.color),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                },
                {
                    label: 'National Average',
                    data: properties.map(() => 100),
                    type: 'line',
                    borderColor: '#e74c3c',
                    borderWidth: 3,
                    borderDash: [10, 5],
                    fill: false,
                    pointRadius: 0
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    callbacks: {
                        footer: () => 'Lower than 100 = Safer than average'
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' (100=avg)'
                    }
                }
            }
        }
    });
}

// Chart 14.5 - Combined Crime Index
function createChart_14_5() {
    const ctx = document.getElementById('chart_14_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Combined Crime Index',
                data: properties.map(p => p.safety.combinedCrimeIndex),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: context => {
                            const prop = properties[context.dataIndex];
                            return prop.safety.crimeDesc;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' (100=avg)'
                    }
                }
            }
        }
    });
}

// =============================================================================
// CATEGORY 15: COMMUNITY & HOA (Charts 71-75)
// =============================================================================

// Chart 15.1 - HOA Fee Comparison
function createChart_15_1() {
    const ctx = document.getElementById('chart_15_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Annual HOA Fee',
                data: properties.map(p => p.community.hoaFeeAnnual),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: context => {
                            const prop = properties[context.dataIndex];
                            return '$' + context.parsed.toLocaleString() + '/year ($' + Math.round(context.parsed/12) + '/mo)';
                        },
                        afterLabel: context => {
                            const prop = properties[context.dataIndex];
                            return prop.community.hasHOA ? prop.community.hoaName : 'No HOA';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => '$' + value.toLocaleString()
                    }
                }
            }
        }
    });
}

// Chart 15.2 - Community Amenities Matrix
function createChart_15_2() {
    const ctx = document.getElementById('chart_15_2');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Pool', 'Clubhouse', 'Fitness', 'Tennis', 'Beach Access', 'Dog Park', 'Gated'],
            datasets: properties.map(p => ({
                label: p.name,
                data: [
                    p.community.hasCommunityPool ? 1 : 0,
                    p.community.hasClubhouse ? 1 : 0,
                    p.community.hasFitnessCenter ? 1 : 0,
                    p.community.hasTennisCourts ? 1 : 0,
                    p.community.hasBeachAccess ? 1 : 0,
                    p.community.hasDogPark ? 1 : 0,
                    p.community.hasGated ? 1 : 0
                ],
                backgroundColor: p.color + '40',
                borderColor: p.color,
                borderWidth: 2,
                pointBackgroundColor: p.color,
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: p.color
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 1,
                    ticks: {
                        stepSize: 1,
                        callback: value => value === 1 ? 'Yes' : 'No'
                    }
                }
            }
        }
    });
}

// Chart 15.3 - Pet Policy Comparison
function createChart_15_3() {
    const ctx = document.getElementById('chart_15_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Max Pet Weight (lbs)',
                data: properties.map(p => p.community.maxPetWeight || 0),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: context => {
                            const prop = properties[context.dataIndex];
                            return prop.community.petPolicy;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value === 0 ? 'No Limit' : value + ' lbs'
                    }
                }
            }
        }
    });
}

// Chart 15.4 - HOA Included Services
function createChart_15_4() {
    const ctx = document.getElementById('chart_15_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Services Included',
                data: properties.map(p => {
                    if (!p.community.hoaIncludes) return 0;
                    return p.community.hoaIncludes.split(',').length;
                }),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: context => {
                            const prop = properties[context.dataIndex];
                            return prop.community.hoaIncludes || 'No HOA';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// Chart 15.5 - Community Features Count
function createChart_15_5() {
    const ctx = document.getElementById('chart_15_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Total Community Amenities',
                data: properties.map(p => p.community.communityAmenityCount),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// =============================================================================
// END OF BATCH 3 FUNCTIONS
// Add these function calls to your initializeAllCharts() function:
// createChart_11_1(); through createChart_15_5();
// =============================================================================
