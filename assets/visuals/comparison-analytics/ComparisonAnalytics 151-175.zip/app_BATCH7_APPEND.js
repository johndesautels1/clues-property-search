// ============================================================================
// BATCH 7 - FINAL BUILD - APP.JS APPEND
// Visualizations 151-175 (Categories 31-35)
// CONVERSATION ID: PROPERTY-VIZ-SESSION-001
// ============================================================================

// ============================================================================
// CATEGORY 31: FUTURE DEVELOPMENT (Charts 151-155)
// ============================================================================

// Chart 31.1 - Planned Infrastructure Projects
function createChart_31_1() {
    const ctx = document.getElementById('chart_31_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Infrastructure Projects Count',
                data: properties.map(p => p.futureDevelopment.plannedInfrastructureProjects),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + ' projects';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Number of Projects',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 31.2 - Zoning Change Probability
function createChart_31_2() {
    const ctx = document.getElementById('chart_31_2');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Zoning Change Probability',
                data: properties.map(p => p.futureDevelopment.zoningChangeProbability),
                backgroundColor: properties.map(p => p.color),
                borderColor: '#1a1f2e',
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    position: 'bottom',
                    labels: { color: '#ffffff', padding: 20 }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed + '%';
                        }
                    }
                }
            }
        }
    });
}

// Chart 31.3 - New Construction in Area
function createChart_31_3() {
    const ctx = document.getElementById('chart_31_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'New Construction Units',
                data: properties.map(p => p.futureDevelopment.newConstructionInArea),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + ' units';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Units Under Construction',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 31.4 - Neighborhood Growth Forecast
function createChart_31_4() {
    const ctx = document.getElementById('chart_31_4');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Growth Forecast (%)',
                data: properties.map(p => p.futureDevelopment.neighborhoodGrowthForecast),
                backgroundColor: properties.map(p => p.color + '40'),
                borderColor: properties.map(p => p.color),
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '%';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: '5-Year Growth Projection',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 31.5 - Future Value Impact Score
function createChart_31_5() {
    const ctx = document.getElementById('chart_31_5');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Future Value Impact',
                data: properties.map(p => p.futureDevelopment.futureValueImpactScore),
                backgroundColor: 'rgba(212, 175, 55, 0.2)',
                borderColor: '#d4af37',
                borderWidth: 2,
                pointBackgroundColor: properties.map(p => p.color),
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: properties.map(p => p.color)
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed.r + '/100';
                        }
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { 
                        color: '#b8c5d6',
                        backdropColor: 'transparent'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    pointLabels: { color: '#ffffff' }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 32: SOCIAL & CULTURAL (Charts 156-160)
// ============================================================================

// Chart 32.1 - Community Engagement Score
function createChart_32_1() {
    const ctx = document.getElementById('chart_32_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Community Engagement Score',
                data: properties.map(p => p.socialCultural.communityEngagementScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Engagement Score (0-100)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 32.2 - Cultural Diversity Index
function createChart_32_2() {
    const ctx = document.getElementById('chart_32_2');
    new Chart(ctx, {
        type: 'polarArea',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Cultural Diversity Index',
                data: properties.map(p => p.socialCultural.culturalDiversityIndex),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    position: 'bottom',
                    labels: { color: '#ffffff', padding: 20 }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed.r + '/100';
                        }
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { 
                        color: '#b8c5d6',
                        backdropColor: 'transparent'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 32.3 - Arts & Cultural Venues
function createChart_32_3() {
    const ctx = document.getElementById('chart_32_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Cultural Venues Count',
                data: properties.map(p => p.socialCultural.artsCulturalVenues),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + ' venues';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Number of Venues',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 32.4 - Social Activity Opportunities
function createChart_32_4() {
    const ctx = document.getElementById('chart_32_4');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Social Activity Score',
                data: properties.map(p => p.socialCultural.socialActivityOpportunities),
                backgroundColor: properties.map(p => p.color + '40'),
                borderColor: properties.map(p => p.color),
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Activity Score',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 32.5 - Volunteer & Civic Organizations
function createChart_32_5() {
    const ctx = document.getElementById('chart_32_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Civic Organizations',
                data: properties.map(p => p.socialCultural.volunteerCivicOrganizations),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + ' organizations';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Number of Organizations',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 33: WORK & CAREER (Charts 161-165)
// ============================================================================

// Chart 33.1 - Job Market Proximity
function createChart_33_1() {
    const ctx = document.getElementById('chart_33_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Distance to Employment Centers',
                data: properties.map(p => p.workCareer.jobMarketProximity),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + ' miles';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + ' mi';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Distance (miles)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 33.2 - Industry Diversity
function createChart_33_2() {
    const ctx = document.getElementById('chart_33_2');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Industry Diversity Score',
                data: properties.map(p => p.workCareer.industryDiversity),
                backgroundColor: 'rgba(74, 158, 255, 0.2)',
                borderColor: '#4a9eff',
                borderWidth: 2,
                pointBackgroundColor: properties.map(p => p.color),
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: properties.map(p => p.color)
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed.r + '/100';
                        }
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { 
                        color: '#b8c5d6',
                        backdropColor: 'transparent'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    pointLabels: { color: '#ffffff' }
                }
            }
        }
    });
}

// Chart 33.3 - Remote Work Suitability
function createChart_33_3() {
    const ctx = document.getElementById('chart_33_3');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Remote Work Suitability',
                data: properties.map(p => p.workCareer.remoteWorkSuitability),
                backgroundColor: properties.map(p => p.color),
                borderColor: '#1a1f2e',
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    position: 'bottom',
                    labels: { color: '#ffffff', padding: 20 }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed + '/100';
                        }
                    }
                }
            }
        }
    });
}

// Chart 33.4 - Coworking Spaces Nearby
function createChart_33_4() {
    const ctx = document.getElementById('chart_33_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Coworking Spaces',
                data: properties.map(p => p.workCareer.coworkingSpacesNearby),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + ' spaces';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Number of Spaces',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 33.5 - Professional Networking Opportunities
function createChart_33_5() {
    const ctx = document.getElementById('chart_33_5');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Networking Opportunities Score',
                data: properties.map(p => p.workCareer.professionalNetworkingOpportunities),
                backgroundColor: properties.map(p => p.color + '40'),
                borderColor: properties.map(p => p.color),
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Networking Score',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 34: FAMILY & CHILDREN (Charts 166-170)
// ============================================================================

// Chart 34.1 - Family-Friendliness Score
function createChart_34_1() {
    const ctx = document.getElementById('chart_34_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Family-Friendliness Score',
                data: properties.map(p => p.familyChildren.familyFriendlinessScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Score (0-100)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 34.2 - Childcare Availability
function createChart_34_2() {
    const ctx = document.getElementById('chart_34_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Childcare Facilities',
                data: properties.map(p => p.familyChildren.childcareAvailability),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + ' facilities';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Number of Facilities',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 34.3 - Youth Programs & Activities
function createChart_34_3() {
    const ctx = document.getElementById('chart_34_3');
    new Chart(ctx, {
        type: 'polarArea',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Youth Programs Count',
                data: properties.map(p => p.familyChildren.youthProgramsActivities),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    position: 'bottom',
                    labels: { color: '#ffffff', padding: 20 }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed.r + ' programs';
                        }
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    ticks: { 
                        color: '#b8c5d6',
                        backdropColor: 'transparent'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 34.4 - Family Entertainment Options
function createChart_34_4() {
    const ctx = document.getElementById('chart_34_4');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Entertainment Options Score',
                data: properties.map(p => p.familyChildren.familyEntertainmentOptions),
                backgroundColor: properties.map(p => p.color + '40'),
                borderColor: properties.map(p => p.color),
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Entertainment Score',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 34.5 - Child Safety Rating
function createChart_34_5() {
    const ctx = document.getElementById('chart_34_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Child Safety Rating',
                data: properties.map(p => p.familyChildren.childSafetyRating),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Safety Rating (0-100)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 35: QUALITY OF LIFE METRICS (Charts 171-175)
// ============================================================================

// Chart 35.1 - Overall Quality of Life Score
function createChart_35_1() {
    const ctx = document.getElementById('chart_35_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Overall Quality of Life',
                data: properties.map(p => p.qualityOfLife.overallQualityOfLifeScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Quality of Life Score',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 35.2 - Stress Level Index
function createChart_35_2() {
    const ctx = document.getElementById('chart_35_2');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Stress Level (Lower is Better)',
                data: properties.map(p => p.qualityOfLife.stressLevelIndex),
                backgroundColor: properties.map(p => p.color + '40'),
                borderColor: properties.map(p => p.color),
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    reverse: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Stress Index (0=Low, 100=High)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 35.3 - Happiness Indicators
function createChart_35_3() {
    const ctx = document.getElementById('chart_35_3');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Happiness Score',
                data: properties.map(p => p.qualityOfLife.happinessIndicators),
                backgroundColor: 'rgba(183, 110, 121, 0.2)',
                borderColor: '#b76e79',
                borderWidth: 2,
                pointBackgroundColor: properties.map(p => p.color),
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: properties.map(p => p.color)
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed.r + '/100';
                        }
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { 
                        color: '#b8c5d6',
                        backdropColor: 'transparent'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    pointLabels: { color: '#ffffff' }
                }
            }
        }
    });
}

// Chart 35.4 - Health & Wellness Opportunities
function createChart_35_4() {
    const ctx = document.getElementById('chart_35_4');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Health & Wellness Score',
                data: properties.map(p => p.qualityOfLife.healthWellnessOpportunities),
                backgroundColor: properties.map(p => p.color),
                borderColor: '#1a1f2e',
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    position: 'bottom',
                    labels: { color: '#ffffff', padding: 20 }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed + '/100';
                        }
                    }
                }
            }
        }
    });
}

// Chart 35.5 - Life Balance Rating
function createChart_35_5() {
    const ctx = document.getElementById('chart_35_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Life Balance Rating',
                data: properties.map(p => p.qualityOfLife.lifeBalanceRating),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Balance Rating (0-100)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// ============================================================================
// END OF BATCH 7 - ALL 25 CHART FUNCTIONS COMPLETE
// Total Functions: createChart_31_1 through createChart_35_5
// ============================================================================
