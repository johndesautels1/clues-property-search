// ============================================================================
// BATCH 4 - DATA ADDITIONS
// Add these fields to each property object in data.js
// ============================================================================

// FOR PROPERTY A (290 41st Ave, St. Pete Beach, FL 33706)
// Add these fields inside the property object:

    // CATEGORY 16: MARKET ANALYSIS
    marketAnalysis: {
        daysOnMarket: 45,
        originalListPrice: 425000,
        priceChanges: 1,
        priceChangeAmount: -10000,
        comparableSalesAvg: 405000,
        yearOverYearAppreciation: 4.2,
        fiveYearAppreciation: 22.5,
        investmentGrade: "B+",
        projectedROI5yr: 18.5
    },

    // CATEGORY 17: ENVIRONMENTAL
    environmental: {
        floodZone: "AE",
        floodRiskLevel: "High",
        hurricaneZone: 1,
        hurricaneRiskScore: 85,
        environmentalHazards: ["Coastal Flooding", "Storm Surge"],
        historicalDisasters: 12,
        climateRiskScore: 72,
        seaLevelRiseConcern: true
    },

    // CATEGORY 18: ZONING & LEGAL
    zoningLegal: {
        zoningType: "RS-1 (Single Family)",
        allowedUses: ["Single Family", "Home Business"],
        buildingHeightLimit: 35,
        lotCoverageMax: 40,
        setbackRequirements: "Front:25ft, Side:7.5ft, Rear:20ft",
        taxAssessedValue: 368000,
        assessmentTrend: "Increasing",
        deedRestrictions: ["No Commercial Use"],
        permitCompliance: true,
        codeViolations: 0
    },

    // CATEGORY 19: ENERGY EFFICIENCY
    energyEfficiency: {
        insulationRValue: 13,
        windowUFactor: 0.65,
        windowSHGC: 0.40,
        monthlyElectricCost: 185,
        monthlyGasCost: 35,
        monthlyWaterCost: 55,
        solarPanels: false,
        energyStarAppliances: 2,
        annualCO2Tons: 8.2,
        greenScore: 48
    },

    // CATEGORY 20: RENTAL POTENTIAL
    rentalPotential: {
        monthlyRentalIncome: 2800,
        annualRentalIncome: 33600,
        vacancyRate: 8,
        capRate: 6.2,
        cashOnCashReturn: 8.5,
        rentalDemandScore: 72,
        shortTermRentalAllowed: true,
        maxRentalDays: 180,
        roi5Year: 42.3
    }

// ============================================================================

// FOR PROPERTY B (4950 Gulf Blvd #1107, St. Pete Beach, FL 33706)
// Add these fields inside the property object:

    // CATEGORY 16: MARKET ANALYSIS
    marketAnalysis: {
        daysOnMarket: 28,
        originalListPrice: 525000,
        priceChanges: 0,
        priceChangeAmount: 0,
        comparableSalesAvg: 515000,
        yearOverYearAppreciation: 5.8,
        fiveYearAppreciation: 28.3,
        investmentGrade: "A",
        projectedROI5yr: 24.2
    },

    // CATEGORY 17: ENVIRONMENTAL
    environmental: {
        floodZone: "VE",
        floodRiskLevel: "High",
        hurricaneZone: 1,
        hurricaneRiskScore: 92,
        environmentalHazards: ["Coastal Flooding", "Storm Surge", "Beach Erosion"],
        historicalDisasters: 15,
        climateRiskScore: 85,
        seaLevelRiseConcern: true
    },

    // CATEGORY 18: ZONING & LEGAL
    zoningLegal: {
        zoningType: "RM-2 (Multi-Family)",
        allowedUses: ["Multi-Family", "Commercial"],
        buildingHeightLimit: 120,
        lotCoverageMax: 65,
        setbackRequirements: "Varies by Building Code",
        taxAssessedValue: 465000,
        assessmentTrend: "Increasing",
        deedRestrictions: ["Condo Association Rules"],
        permitCompliance: true,
        codeViolations: 0
    },

    // CATEGORY 19: ENERGY EFFICIENCY
    energyEfficiency: {
        insulationRValue: 19,
        windowUFactor: 0.32,
        windowSHGC: 0.25,
        monthlyElectricCost: 145,
        monthlyGasCost: 0,
        monthlyWaterCost: 0,
        solarPanels: false,
        energyStarAppliances: 6,
        annualCO2Tons: 5.8,
        greenScore: 72
    },

    // CATEGORY 20: RENTAL POTENTIAL
    rentalPotential: {
        monthlyRentalIncome: 3500,
        annualRentalIncome: 42000,
        vacancyRate: 12,
        capRate: 5.8,
        cashOnCashReturn: 7.2,
        rentalDemandScore: 88,
        shortTermRentalAllowed: true,
        maxRentalDays: 365,
        roi5Year: 38.5
    }

// ============================================================================

// FOR PROPERTY C (10400 Gandy Blvd N, St. Petersburg, FL 33702)
// Add these fields inside the property object:

    // CATEGORY 16: MARKET ANALYSIS
    marketAnalysis: {
        daysOnMarket: 62,
        originalListPrice: 399900,
        priceChanges: 2,
        priceChangeAmount: -10000,
        comparableSalesAvg: 395000,
        yearOverYearAppreciation: 3.8,
        fiveYearAppreciation: 19.2,
        investmentGrade: "B",
        projectedROI5yr: 16.8
    },

    // CATEGORY 17: ENVIRONMENTAL
    environmental: {
        floodZone: "X",
        floodRiskLevel: "Low",
        hurricaneZone: 2,
        hurricaneRiskScore: 65,
        environmentalHazards: ["Tropical Storms"],
        historicalDisasters: 8,
        climateRiskScore: 58,
        seaLevelRiseConcern: false
    },

    // CATEGORY 18: ZONING & LEGAL
    zoningLegal: {
        zoningType: "RS-2 (Single Family)",
        allowedUses: ["Single Family", "Home Business"],
        buildingHeightLimit: 35,
        lotCoverageMax: 45,
        setbackRequirements: "Front:25ft, Side:7.5ft, Rear:20ft",
        taxAssessedValue: 345000,
        assessmentTrend: "Stable",
        deedRestrictions: ["55+ Community", "No Commercial"],
        permitCompliance: true,
        codeViolations: 0
    },

    // CATEGORY 19: ENERGY EFFICIENCY
    energyEfficiency: {
        insulationRValue: 16,
        windowUFactor: 0.45,
        windowSHGC: 0.30,
        monthlyElectricCost: 165,
        monthlyGasCost: 0,
        monthlyWaterCost: 48,
        solarPanels: false,
        energyStarAppliances: 4,
        annualCO2Tons: 6.8,
        greenScore: 62
    },

    // CATEGORY 20: RENTAL POTENTIAL
    rentalPotential: {
        monthlyRentalIncome: 2600,
        annualRentalIncome: 31200,
        vacancyRate: 6,
        capRate: 6.8,
        cashOnCashReturn: 9.2,
        rentalDemandScore: 65,
        shortTermRentalAllowed: false,
        maxRentalDays: 0,
        roi5Year: 45.8
    }

// ============================================================================
// END OF BATCH 4 DATA ADDITIONS
// ============================================================================
