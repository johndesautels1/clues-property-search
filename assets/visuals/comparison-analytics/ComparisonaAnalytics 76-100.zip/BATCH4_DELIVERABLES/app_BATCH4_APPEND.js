// ============================================================================
// BATCH 4 - CHART FUNCTIONS (76-100)
// Category 16: Market Analysis
// Category 17: Environmental
// Category 18: Zoning & Legal
// Category 19: Energy Efficiency
// Category 20: Rental Potential
// ============================================================================

// ============================================================================
// CATEGORY 16: MARKET ANALYSIS
// ============================================================================

// Chart 16.1 - Days on Market
function createChart_16_1() {
    const ctx = document.getElementById('chart_16_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Days on Market',
                data: properties.map(p => p.marketAnalysis.daysOnMarket),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y + ' days';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Days',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 16.2 - Price History
function createChart_16_2() {
    const ctx = document.getElementById('chart_16_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Original List Price',
                    data: properties.map(p => p.marketAnalysis.originalListPrice),
                    backgroundColor: properties.map(p => p.color + '80'),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                },
                {
                    label: 'Current Price',
                    data: properties.map(p => p.price),
                    backgroundColor: properties.map(p => p.color),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000) + 'k';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Price',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 16.3 - Comparable Sales
function createChart_16_3() {
    const ctx = document.getElementById('chart_16_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Current Price',
                    data: properties.map(p => p.price),
                    backgroundColor: properties.map(p => p.color),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                },
                {
                    label: 'Comparable Sales Avg',
                    data: properties.map(p => p.marketAnalysis.comparableSalesAvg),
                    backgroundColor: 'rgba(255, 255, 255, 0.2)',
                    borderColor: '#ffffff',
                    borderWidth: 2,
                    borderDash: [5, 5]
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000) + 'k';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Price',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 16.4 - Market Appreciation
function createChart_16_4() {
    const ctx = document.getElementById('chart_16_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: '1-Year Appreciation',
                    data: properties.map(p => p.marketAnalysis.yearOverYearAppreciation),
                    backgroundColor: properties.map(p => p.color + '80'),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                },
                {
                    label: '5-Year Appreciation',
                    data: properties.map(p => p.marketAnalysis.fiveYearAppreciation),
                    backgroundColor: properties.map(p => p.color),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '%';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Appreciation %',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 16.5 - Investment Potential
function createChart_16_5() {
    const ctx = document.getElementById('chart_16_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Projected 5-Year ROI',
                data: properties.map(p => p.marketAnalysis.projectedROI5yr),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'ROI: ' + context.parsed.y + '%';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'ROI %',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 17: ENVIRONMENTAL
// ============================================================================

// Chart 17.1 - Flood Zone Rating
function createChart_17_1() {
    const ctx = document.getElementById('chart_17_1');
    
    // Create risk scores based on flood zone
    const floodRiskMap = {
        'X': 20,
        'AE': 75,
        'VE': 95
    };
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Flood Risk Score',
                data: properties.map(p => floodRiskMap[p.environmental.floodZone] || 0),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Zone: ' + prop.environmental.floodZone,
                                'Risk: ' + prop.environmental.floodRiskLevel,
                                'Score: ' + context.parsed.y
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Risk Score (0-100)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 17.2 - Hurricane Risk
function createChart_17_2() {
    const ctx = document.getElementById('chart_17_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Hurricane Risk Score',
                data: properties.map(p => p.environmental.hurricaneRiskScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Risk Score: ' + context.parsed.y,
                                'Hurricane Zone: ' + prop.environmental.hurricaneZone
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Risk Score (0-100)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 17.3 - Environmental Hazards
function createChart_17_3() {
    const ctx = document.getElementById('chart_17_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Number of Hazards',
                data: properties.map(p => p.environmental.environmentalHazards.length),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Hazards: ' + context.parsed.y,
                                'Types: ' + prop.environmental.environmentalHazards.join(', ')
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        color: '#b8c5d6',
                        stepSize: 1
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Hazard Count',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 17.4 - Natural Disaster History
function createChart_17_4() {
    const ctx = document.getElementById('chart_17_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Historical Disasters',
                data: properties.map(p => p.environmental.historicalDisasters),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Past Events: ' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        color: '#b8c5d6',
                        stepSize: 2
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Event Count',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 17.5 - Climate Risk Score
function createChart_17_5() {
    const ctx = document.getElementById('chart_17_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Climate Risk Score',
                data: properties.map(p => p.environmental.climateRiskScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Risk Score: ' + context.parsed.y,
                                'Sea Level Concern: ' + (prop.environmental.seaLevelRiseConcern ? 'Yes' : 'No')
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Risk Score (0-100)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 18: ZONING & LEGAL
// ============================================================================

// Chart 18.1 - Zoning Type
function createChart_18_1() {
    const ctx = document.getElementById('chart_18_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Zoning Classification',
                data: properties.map((p, i) => i + 1),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Zoning: ' + prop.zoningLegal.zoningType,
                                'Uses: ' + prop.zoningLegal.allowedUses.join(', ')
                            ];
                        }
                    }
                }
            },
            scales: {
                x: {
                    display: false
                },
                y: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 18.2 - Building Restrictions
function createChart_18_2() {
    const ctx = document.getElementById('chart_18_2');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Height Limit', 'Lot Coverage', 'Setback Score'],
            datasets: properties.map(p => ({
                label: p.name,
                data: [
                    (p.zoningLegal.buildingHeightLimit / 120) * 100,
                    p.zoningLegal.lotCoverageMax,
                    60
                ],
                backgroundColor: p.color + '40',
                borderColor: p.color,
                borderWidth: 2,
                pointBackgroundColor: p.color,
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: p.color
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.datasetIndex];
                            if (context.dataIndex === 0) {
                                return prop.name + ' - Height: ' + prop.zoningLegal.buildingHeightLimit + 'ft';
                            } else if (context.dataIndex === 1) {
                                return prop.name + ' - Coverage: ' + prop.zoningLegal.lotCoverageMax + '%';
                            } else {
                                return prop.name + ' - Setbacks: ' + prop.zoningLegal.setbackRequirements;
                            }
                        }
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { 
                        color: '#b8c5d6',
                        backdropColor: 'transparent'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    pointLabels: { color: '#ffffff' }
                }
            }
        }
    });
}

// Chart 18.3 - Tax Assessment History
function createChart_18_3() {
    const ctx = document.getElementById('chart_18_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Tax Assessed Value',
                data: properties.map(p => p.zoningLegal.taxAssessedValue),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Assessed: $' + context.parsed.y.toLocaleString(),
                                'Trend: ' + prop.zoningLegal.assessmentTrend
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000) + 'k';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Assessed Value',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 18.4 - Deed Restrictions
function createChart_18_4() {
    const ctx = document.getElementById('chart_18_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Number of Restrictions',
                data: properties.map(p => p.zoningLegal.deedRestrictions.length),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Restrictions: ' + context.parsed.y,
                                'Types: ' + prop.zoningLegal.deedRestrictions.join(', ')
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        color: '#b8c5d6',
                        stepSize: 1
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Restriction Count',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 18.5 - Legal Compliance
function createChart_18_5() {
    const ctx = document.getElementById('chart_18_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Compliance Score',
                data: properties.map(p => p.zoningLegal.permitCompliance ? 100 : 0),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Permit Compliance: ' + (prop.zoningLegal.permitCompliance ? 'Yes' : 'No'),
                                'Code Violations: ' + prop.zoningLegal.codeViolations
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Compliance %',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 19: ENERGY EFFICIENCY
// ============================================================================

// Chart 19.1 - Insulation Rating
function createChart_19_1() {
    const ctx = document.getElementById('chart_19_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'R-Value',
                data: properties.map(p => p.energyEfficiency.insulationRValue),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'R-Value: ' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'R-Value',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 19.2 - Window Efficiency
function createChart_19_2() {
    const ctx = document.getElementById('chart_19_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'U-Factor',
                    data: properties.map(p => p.energyEfficiency.windowUFactor),
                    backgroundColor: properties.map(p => p.color + '80'),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                },
                {
                    label: 'SHGC',
                    data: properties.map(p => p.energyEfficiency.windowSHGC),
                    backgroundColor: properties.map(p => p.color),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Rating (Lower is Better)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 19.3 - Energy Costs
function createChart_19_3() {
    const ctx = document.getElementById('chart_19_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Electric',
                    data: properties.map(p => p.energyEfficiency.monthlyElectricCost),
                    backgroundColor: properties.map(p => p.color),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                },
                {
                    label: 'Gas',
                    data: properties.map(p => p.energyEfficiency.monthlyGasCost),
                    backgroundColor: properties.map(p => p.color + '80'),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                },
                {
                    label: 'Water',
                    data: properties.map(p => p.energyEfficiency.monthlyWaterCost),
                    backgroundColor: properties.map(p => p.color + '60'),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': $' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + value;
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Monthly Cost',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 19.4 - Green Features
function createChart_19_4() {
    const ctx = document.getElementById('chart_19_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Energy Star Appliances',
                data: properties.map(p => p.energyEfficiency.energyStarAppliances),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Energy Star Appliances: ' + context.parsed.y,
                                'Solar Panels: ' + (prop.energyEfficiency.solarPanels ? 'Yes' : 'No'),
                                'Green Score: ' + prop.energyEfficiency.greenScore
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        color: '#b8c5d6',
                        stepSize: 1
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Appliance Count',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 19.5 - Carbon Footprint
function createChart_19_5() {
    const ctx = document.getElementById('chart_19_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Annual CO2 Emissions',
                data: properties.map(p => p.energyEfficiency.annualCO2Tons),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y + ' tons CO2/year';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + ' tons';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'CO2 Tons/Year',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 20: RENTAL POTENTIAL
// ============================================================================

// Chart 20.1 - Rental Income Potential
function createChart_20_1() {
    const ctx = document.getElementById('chart_20_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Monthly Income',
                    data: properties.map(p => p.rentalPotential.monthlyRentalIncome),
                    backgroundColor: properties.map(p => p.color + '80'),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                },
                {
                    label: 'Annual Income',
                    data: properties.map(p => p.rentalPotential.annualRentalIncome / 12),
                    backgroundColor: properties.map(p => p.color),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: { color: '#ffffff' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            if (context.datasetIndex === 0) {
                                return 'Monthly: $' + context.parsed.y.toLocaleString();
                            } else {
                                const prop = properties[context.dataIndex];
                                return 'Annual: $' + prop.rentalPotential.annualRentalIncome.toLocaleString();
                            }
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000) + 'k';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Rental Income',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 20.2 - Cap Rate Analysis
function createChart_20_2() {
    const ctx = document.getElementById('chart_20_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Cap Rate',
                data: properties.map(p => p.rentalPotential.capRate),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Cap Rate: ' + context.parsed.y + '%',
                                'Cash-on-Cash: ' + prop.rentalPotential.cashOnCashReturn + '%'
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Cap Rate %',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 20.3 - Rental Demand
function createChart_20_3() {
    const ctx = document.getElementById('chart_20_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Rental Demand Score',
                data: properties.map(p => p.rentalPotential.rentalDemandScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Demand Score: ' + context.parsed.y,
                                'Vacancy Rate: ' + prop.rentalPotential.vacancyRate + '%'
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Demand Score (0-100)',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 20.4 - Short-term Rental Rules
function createChart_20_4() {
    const ctx = document.getElementById('chart_20_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Max Rental Days/Year',
                data: properties.map(p => p.rentalPotential.maxRentalDays),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const prop = properties[context.dataIndex];
                            return [
                                'Max Days: ' + context.parsed.y,
                                'STR Allowed: ' + (prop.rentalPotential.shortTermRentalAllowed ? 'Yes' : 'No')
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 365,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + ' days';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'Days Allowed',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// Chart 20.5 - ROI Projection
function createChart_20_5() {
    const ctx = document.getElementById('chart_20_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: '5-Year ROI Projection',
                data: properties.map(p => p.rentalPotential.roi5Year),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return '5-Year ROI: ' + context.parsed.y + '%';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    title: {
                        display: true,
                        text: 'ROI %',
                        color: '#b8c5d6'
                    }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

// ============================================================================
// END OF BATCH 4 FUNCTIONS
// ============================================================================
