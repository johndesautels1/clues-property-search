// ============================================================================
// BATCH 5: DATA STRUCTURES
// Property Visualization Dashboard - Data for Categories 21-25
// Categories: Property Condition, Insurance, Technology, Outdoor Space, Privacy & Security
// ============================================================================

// ============================================================================
// PROPERTY A DATA - CATEGORIES 21-25
// ============================================================================

// Category 21: Property Condition
propertyCondition: {
    overallConditionScore: 92,
    ageOfMajorSystems: {
        HVAC: 3,
        Roof: 2,
        'Water Heater': 4,
        Electrical: 5,
        Plumbing: 6
    },
    recentRenovations: 5,
    inspectionIssues: {
        Minor: 2,
        Moderate: 1,
        Major: 0
    },
    maintenanceRequired: 3500
},

// Category 22: Insurance
insurance: {
    homeownersInsurance: 2800,
    floodInsurance: 1200,
    windInsurance: 800,
    claimsHistory: 0
},

// Category 23: Technology
technology: {
    internetSpeed: 1000,
    smartHomeFeatures: 12,
    securitySystem: 9,
    homeAutomationScore: 85,
    techInfrastructure: {
        Internet: 10,
        'Smart Home': 9,
        Security: 9,
        Automation: 8,
        Wiring: 9
    }
},

// Category 24: Outdoor Space
outdoorSpace: {
    yardSize: 8500,
    outdoorAmenities: 6,
    landscapingQuality: 9,
    outdoorLivingSpace: 800,
    gardenMaintenance: 350
},

// Category 25: Privacy & Security
privacySecurity: {
    privacyRating: 9,
    securityFeaturesCount: 8,
    gatedCommunity: true,
    surveillanceCoverage: 90,
    neighborhoodWatch: 8
}

// ============================================================================
// PROPERTY B DATA - CATEGORIES 21-25
// ============================================================================

// Category 21: Property Condition
propertyCondition: {
    overallConditionScore: 85,
    ageOfMajorSystems: {
        HVAC: 5,
        Roof: 7,
        'Water Heater': 6,
        Electrical: 8,
        Plumbing: 10
    },
    recentRenovations: 3,
    inspectionIssues: {
        Minor: 4,
        Moderate: 2,
        Major: 1
    },
    maintenanceRequired: 5200
},

// Category 22: Insurance
insurance: {
    homeownersInsurance: 2200,
    floodInsurance: 800,
    windInsurance: 600,
    claimsHistory: 1
},

// Category 23: Technology
technology: {
    internetSpeed: 500,
    smartHomeFeatures: 7,
    securitySystem: 7,
    homeAutomationScore: 65,
    techInfrastructure: {
        Internet: 8,
        'Smart Home': 7,
        Security: 7,
        Automation: 6,
        Wiring: 7
    }
},

// Category 24: Outdoor Space
outdoorSpace: {
    yardSize: 6000,
    outdoorAmenities: 4,
    landscapingQuality: 7,
    outdoorLivingSpace: 500,
    gardenMaintenance: 250
},

// Category 25: Privacy & Security
privacySecurity: {
    privacyRating: 7,
    securityFeaturesCount: 5,
    gatedCommunity: false,
    surveillanceCoverage: 70,
    neighborhoodWatch: 6
}

// ============================================================================
// PROPERTY C DATA - CATEGORIES 21-25
// ============================================================================

// Category 21: Property Condition
propertyCondition: {
    overallConditionScore: 78,
    ageOfMajorSystems: {
        HVAC: 8,
        Roof: 12,
        'Water Heater': 9,
        Electrical: 15,
        Plumbing: 18
    },
    recentRenovations: 2,
    inspectionIssues: {
        Minor: 6,
        Moderate: 3,
        Major: 2
    },
    maintenanceRequired: 8500
},

// Category 22: Insurance
insurance: {
    homeownersInsurance: 3200,
    floodInsurance: 1800,
    windInsurance: 1200,
    claimsHistory: 3
},

// Category 23: Technology
technology: {
    internetSpeed: 300,
    smartHomeFeatures: 4,
    securitySystem: 5,
    homeAutomationScore: 45,
    techInfrastructure: {
        Internet: 6,
        'Smart Home': 5,
        Security: 5,
        Automation: 4,
        Wiring: 5
    }
},

// Category 24: Outdoor Space
outdoorSpace: {
    yardSize: 12000,
    outdoorAmenities: 3,
    landscapingQuality: 6,
    outdoorLivingSpace: 350,
    gardenMaintenance: 450
},

// Category 25: Privacy & Security
privacySecurity: {
    privacyRating: 8,
    securityFeaturesCount: 6,
    gatedCommunity: true,
    surveillanceCoverage: 60,
    neighborhoodWatch: 7
}

// ============================================================================
// USAGE INSTRUCTIONS
// ============================================================================
// 
// Copy each property's data blocks above and add them to the corresponding
// property object in your main data.js file.
//
// For Property A: Add all Category 21-25 data blocks
// For Property B: Add all Category 21-25 data blocks  
// For Property C: Add all Category 21-25 data blocks
//
// Make sure to add commas between existing categories and new categories.
//
// ============================================================================
