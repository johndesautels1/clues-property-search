// ============================================================================
// BATCH 5: VISUALIZATIONS 101-125
// Property Visualization Dashboard - Chart Functions
// Categories 21-25: Property Condition, Insurance, Technology, Outdoor Space, Privacy & Security
// ============================================================================

// ============================================================================
// CATEGORY 21: PROPERTY CONDITION (Charts 101-105)
// ============================================================================

// Chart 21.1 - Overall Condition Score (Chart 101)
function createChart_21_1() {
    const ctx = document.getElementById('chart_21_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Overall Condition Score',
                data: properties.map(p => p.propertyCondition.overallConditionScore),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Condition Score: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value;
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 21.2 - Age of Major Systems (Chart 102)
function createChart_21_2() {
    const ctx = document.getElementById('chart_21_2');
    
    const systemTypes = ['HVAC', 'Roof', 'Water Heater', 'Electrical', 'Plumbing'];
    const datasets = properties.map((property, index) => ({
        label: property.name,
        data: systemTypes.map(system => property.propertyCondition.ageOfMajorSystems[system]),
        backgroundColor: property.color + '80',
        borderColor: property.color,
        borderWidth: 2
    }));

    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: systemTypes,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.r + ' years old';
                        }
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    angleLines: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        backdropColor: 'transparent'
                    },
                    pointLabels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                        }
                    }
                }
            }
        }
    });
}

// Chart 21.3 - Recent Renovations (Chart 103)
function createChart_21_3() {
    const ctx = document.getElementById('chart_21_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Number of Recent Renovations',
                data: properties.map(p => p.propertyCondition.recentRenovations),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Renovations: ' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        stepSize: 1
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 21.4 - Inspection Issues (Chart 104)
function createChart_21_4() {
    const ctx = document.getElementById('chart_21_4');
    
    const issueTypes = ['Minor', 'Moderate', 'Major'];
    const datasets = issueTypes.map((issueType, index) => {
        const colors = ['#4ade80', '#fbbf24', '#ef4444'];
        return {
            label: issueType + ' Issues',
            data: properties.map(p => p.propertyCondition.inspectionIssues[issueType]),
            backgroundColor: colors[index] + '80',
            borderColor: colors[index],
            borderWidth: 2
        };
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    stacked: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        stepSize: 1
                    }
                },
                x: {
                    stacked: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 21.5 - Maintenance Required (Chart 105)
function createChart_21_5() {
    const ctx = document.getElementById('chart_21_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Annual Maintenance Cost',
                data: properties.map(p => p.propertyCondition.maintenanceRequired),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Annual Cost: $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000) + 'K';
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 22: INSURANCE (Charts 106-110)
// ============================================================================

// Chart 22.1 - Homeowner's Insurance Cost (Chart 106)
function createChart_22_1() {
    const ctx = document.getElementById('chart_22_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Annual Homeowner\'s Insurance',
                data: properties.map(p => p.insurance.homeownersInsurance),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Annual Cost: $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000) + 'K';
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 22.2 - Flood Insurance Cost (Chart 107)
function createChart_22_2() {
    const ctx = document.getElementById('chart_22_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Annual Flood Insurance',
                data: properties.map(p => p.insurance.floodInsurance),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Annual Cost: $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000) + 'K';
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 22.3 - Wind Insurance Cost (Chart 108)
function createChart_22_3() {
    const ctx = document.getElementById('chart_22_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Annual Wind Insurance',
                data: properties.map(p => p.insurance.windInsurance),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Annual Cost: $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000) + 'K';
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 22.4 - Total Insurance Costs (Chart 109)
function createChart_22_4() {
    const ctx = document.getElementById('chart_22_4');
    
    const insuranceTypes = ['Homeowners', 'Flood', 'Wind'];
    const datasets = insuranceTypes.map((type, index) => {
        const colors = ['#d4af37', '#4a9eff', '#b76e79'];
        const dataMap = {
            'Homeowners': properties.map(p => p.insurance.homeownersInsurance),
            'Flood': properties.map(p => p.insurance.floodInsurance),
            'Wind': properties.map(p => p.insurance.windInsurance)
        };
        
        return {
            label: type + ' Insurance',
            data: dataMap[type],
            backgroundColor: colors[index] + '80',
            borderColor: colors[index],
            borderWidth: 2
        };
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    stacked: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000) + 'K';
                        }
                    }
                },
                x: {
                    stacked: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 22.5 - Insurance Claims History (Chart 110)
function createChart_22_5() {
    const ctx = document.getElementById('chart_22_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Claims in Past 5 Years',
                data: properties.map(p => p.insurance.claimsHistory),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Claims: ' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        stepSize: 1
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 23: TECHNOLOGY (Charts 111-115)
// ============================================================================

// Chart 23.1 - Internet Speed Available (Chart 111)
function createChart_23_1() {
    const ctx = document.getElementById('chart_23_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Max Internet Speed (Mbps)',
                data: properties.map(p => p.technology.internetSpeed),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Speed: ' + context.parsed.y + ' Mbps';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + ' Mbps';
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 23.2 - Smart Home Features (Chart 112)
function createChart_23_2() {
    const ctx = document.getElementById('chart_23_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Smart Home Features Count',
                data: properties.map(p => p.technology.smartHomeFeatures),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Features: ' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        stepSize: 1
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 23.3 - Security System (Chart 113)
function createChart_23_3() {
    const ctx = document.getElementById('chart_23_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Security System Rating',
                data: properties.map(p => p.technology.securitySystem),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Rating: ' + context.parsed.y + '/10';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 23.4 - Home Automation Score (Chart 114)
function createChart_23_4() {
    const ctx = document.getElementById('chart_23_4');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Home Automation Score',
                data: properties.map(p => p.technology.homeAutomationScore),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed + '/100';
                        }
                    }
                }
            }
        }
    });
}

// Chart 23.5 - Tech Infrastructure Rating (Chart 115)
function createChart_23_5() {
    const ctx = document.getElementById('chart_23_5');
    
    const techCategories = ['Internet', 'Smart Home', 'Security', 'Automation', 'Wiring'];
    const datasets = properties.map((property, index) => ({
        label: property.name,
        data: techCategories.map(cat => property.technology.techInfrastructure[cat]),
        backgroundColor: property.color + '40',
        borderColor: property.color,
        borderWidth: 2,
        pointBackgroundColor: property.color,
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: property.color
    }));

    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: techCategories,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.r + '/10';
                        }
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 10,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    angleLines: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        backdropColor: 'transparent',
                        stepSize: 2
                    },
                    pointLabels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                        }
                    }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 24: OUTDOOR SPACE (Charts 116-120)
// ============================================================================

// Chart 24.1 - Yard Size (Chart 116)
function createChart_24_1() {
    const ctx = document.getElementById('chart_24_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Yard Size (sq ft)',
                data: properties.map(p => p.outdoorSpace.yardSize),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Size: ' + context.parsed.y.toLocaleString() + ' sq ft';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return (value / 1000).toFixed(1) + 'K';
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 24.2 - Outdoor Amenities (Chart 117)
function createChart_24_2() {
    const ctx = document.getElementById('chart_24_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Outdoor Amenities Count',
                data: properties.map(p => p.outdoorSpace.outdoorAmenities),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Amenities: ' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        stepSize: 1
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 24.3 - Landscaping Quality (Chart 118)
function createChart_24_3() {
    const ctx = document.getElementById('chart_24_3');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Landscaping Quality Rating',
                data: properties.map(p => p.outdoorSpace.landscapingQuality),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Quality: ' + context.parsed.y + '/10';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 24.4 - Outdoor Living Space (Chart 119)
function createChart_24_4() {
    const ctx = document.getElementById('chart_24_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Outdoor Living Space (sq ft)',
                data: properties.map(p => p.outdoorSpace.outdoorLivingSpace),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Space: ' + context.parsed.y.toLocaleString() + ' sq ft';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + ' sq ft';
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 24.5 - Garden/Lawn Maintenance (Chart 120)
function createChart_24_5() {
    const ctx = document.getElementById('chart_24_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Monthly Maintenance Cost',
                data: properties.map(p => p.outdoorSpace.gardenMaintenance),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Monthly Cost: $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + value;
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// ============================================================================
// CATEGORY 25: PRIVACY & SECURITY (Charts 121-125)
// ============================================================================

// Chart 25.1 - Privacy Rating (Chart 121)
function createChart_25_1() {
    const ctx = document.getElementById('chart_25_1');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Privacy Rating',
                data: properties.map(p => p.privacySecurity.privacyRating),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Rating: ' + context.parsed.y + '/10';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 25.2 - Security Features Count (Chart 122)
function createChart_25_2() {
    const ctx = document.getElementById('chart_25_2');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Security Features',
                data: properties.map(p => p.privacySecurity.securityFeaturesCount),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Features: ' + context.parsed.y;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        stepSize: 1
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 25.3 - Gated Community Status (Chart 123)
function createChart_25_3() {
    const ctx = document.getElementById('chart_25_3');
    
    const gatedData = properties.map(p => p.privacySecurity.gatedCommunity ? 1 : 0);
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Gated Community',
                data: gatedData,
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            const property = properties[context.dataIndex];
                            return property.name + ': ' + (property.privacySecurity.gatedCommunity ? 'Yes' : 'No');
                        }
                    }
                }
            }
        }
    });
}

// Chart 25.4 - Surveillance Coverage (Chart 124)
function createChart_25_4() {
    const ctx = document.getElementById('chart_25_4');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Surveillance Coverage %',
                data: properties.map(p => p.privacySecurity.surveillanceCoverage),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Coverage: ' + context.parsed.y + '%';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// Chart 25.5 - Neighborhood Watch Presence (Chart 125)
function createChart_25_5() {
    const ctx = document.getElementById('chart_25_5');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Neighborhood Watch Rating',
                data: properties.map(p => p.privacySecurity.neighborhoodWatch),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    callbacks: {
                        label: function(context) {
                            return 'Rating: ' + context.parsed.y + '/10';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8c5d6'
                    }
                }
            }
        }
    });
}

// ============================================================================
// END OF BATCH 5
// Total Functions: 25 (Charts 101-125)
// Categories: 21-25
// ============================================================================
