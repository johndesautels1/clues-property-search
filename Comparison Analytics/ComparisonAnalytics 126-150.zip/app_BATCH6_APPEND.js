// ============================================
// BATCH 6: CHARTS 126-150
// Category 26: Historical Data (Charts 126-130)
// Category 27: Resale Potential (Charts 131-135)
// Category 28: Lifestyle Fit (Charts 136-140)
// Category 29: Natural Disasters (Charts 141-145)
// Category 30: Accessibility (Charts 146-150)
// ============================================

// CATEGORY 26: HISTORICAL DATA
// ============================================

// Chart 126: Property Value History (Last 10 Years)
function createChart_26_1() {
    const ctx = document.getElementById('chart_26_1');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: properties[0].historicalData.valueHistory.years,
            datasets: properties.map((property, index) => ({
                label: property.name,
                data: property.historicalData.valueHistory.values,
                borderColor: property.color,
                backgroundColor: property.color + '20',
                borderWidth: 3,
                tension: 0.4,
                fill: true
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000).toFixed(0) + 'K';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 127: Previous Sale Prices
function createChart_26_2() {
    const ctx = document.getElementById('chart_26_2');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties[0].historicalData.previousSales.dates,
            datasets: properties.map((property, index) => ({
                label: property.name,
                data: property.historicalData.previousSales.prices,
                backgroundColor: property.color,
                borderColor: property.color,
                borderWidth: 2
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000).toFixed(0) + 'K';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 128: Time on Market History
function createChart_26_3() {
    const ctx = document.getElementById('chart_26_3');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: properties[0].historicalData.timeOnMarket.years,
            datasets: properties.map((property, index) => ({
                label: property.name,
                data: property.historicalData.timeOnMarket.days,
                borderColor: property.color,
                backgroundColor: property.color + '40',
                borderWidth: 3,
                tension: 0.3,
                fill: false
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + ' days';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + ' days';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 129: Owner History
function createChart_26_4() {
    const ctx = document.getElementById('chart_26_4');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Number of Previous Owners',
                data: properties.map(p => p.historicalData.ownerHistory.owners.length),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const property = properties[context.dataIndex];
                            return [
                                'Total Owners: ' + context.parsed.y,
                                'Latest: ' + property.historicalData.ownerHistory.owners[property.historicalData.ownerHistory.owners.length - 1]
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        stepSize: 1
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 130: Renovation Timeline
function createChart_26_5() {
    const ctx = document.getElementById('chart_26_5');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Total Renovation Investment',
                data: properties.map(p => p.historicalData.renovationTimeline.costs.reduce((a, b) => a + b, 0)),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const property = properties[context.dataIndex];
                            const lines = ['Total Investment: $' + context.parsed.y.toLocaleString()];
                            property.historicalData.renovationTimeline.projects.forEach((project, i) => {
                                lines.push(property.historicalData.renovationTimeline.years[i] + ': ' + project + ' ($' + property.historicalData.renovationTimeline.costs[i].toLocaleString() + ')');
                            });
                            return lines;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000).toFixed(0) + 'K';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// CATEGORY 27: RESALE POTENTIAL
// ============================================

// Chart 131: Projected Resale Value (5 Years)
function createChart_27_1() {
    const ctx = document.getElementById('chart_27_1');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Current Value',
                    data: properties.map(p => p.price),
                    backgroundColor: properties.map(p => p.color + '60'),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                },
                {
                    label: 'Projected 5-Year Value',
                    data: properties.map(p => p.resalePotential.projectedValue5Year),
                    backgroundColor: properties.map(p => p.color),
                    borderColor: properties.map(p => p.color),
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': $' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return '$' + (value / 1000).toFixed(0) + 'K';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 132: Market Demand Score
function createChart_27_2() {
    const ctx = document.getElementById('chart_27_2');
    
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Market Demand Score',
                data: properties.map(p => p.resalePotential.marketDemandScore),
                backgroundColor: 'rgba(212, 175, 55, 0.2)',
                borderColor: '#d4af37',
                borderWidth: 3,
                pointBackgroundColor: properties.map(p => p.color),
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        backdropColor: 'transparent',
                        stepSize: 20
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    pointLabels: {
                        color: '#ffffff',
                        font: {
                            size: 12
                        }
                    }
                }
            }
        }
    });
}

// Chart 133: Days to Sell Estimate
function createChart_27_3() {
    const ctx = document.getElementById('chart_27_3');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Estimated Days to Sell',
                data: properties.map(p => p.resalePotential.daysToSellEstimate),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y + ' days';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + ' days';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 134: Buyer Pool Size
function createChart_27_4() {
    const ctx = document.getElementById('chart_27_4');
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Potential Buyers',
                data: properties.map(p => p.resalePotential.buyerPoolSize),
                backgroundColor: properties.map(p => p.color),
                borderColor: '#0a0e14',
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                            size: 12
                        },
                        padding: 20
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed.toLocaleString() + ' buyers';
                        }
                    }
                }
            }
        }
    });
}

// Chart 135: Desirability Index
function createChart_27_5() {
    const ctx = document.getElementById('chart_27_5');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Desirability Index',
                data: properties.map(p => p.resalePotential.desirabilityIndex),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Score: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// CATEGORY 28: LIFESTYLE FIT
// ============================================

// Chart 136: Overall Lifestyle Match Score
function createChart_28_1() {
    const ctx = document.getElementById('chart_28_1');
    
    new Chart(ctx, {
        type: 'polarArea',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Lifestyle Match',
                data: properties.map(p => p.lifestyleFit.overallMatchScore),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                            size: 12
                        },
                        padding: 20
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed.r + '/100';
                        }
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        backdropColor: 'transparent',
                        stepSize: 20
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 137: Work-Life Balance Rating
function createChart_28_2() {
    const ctx = document.getElementById('chart_28_2');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Work-Life Balance',
                data: properties.map(p => p.lifestyleFit.workLifeBalanceRating),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Rating: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 138: Entertainment Options Score
function createChart_28_3() {
    const ctx = document.getElementById('chart_28_3');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Entertainment Options',
                data: properties.map(p => p.lifestyleFit.entertainmentOptionsScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Score: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 139: Cultural Fit Rating
function createChart_28_4() {
    const ctx = document.getElementById('chart_28_4');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Cultural Fit',
                data: properties.map(p => p.lifestyleFit.culturalFitRating),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Rating: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 140: Climate Preference Match
function createChart_28_5() {
    const ctx = document.getElementById('chart_28_5');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Climate Match',
                data: properties.map(p => p.lifestyleFit.climatePreferenceMatch),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Match: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// CATEGORY 29: NATURAL DISASTERS
// ============================================

// Chart 141: Flood Risk Rating
function createChart_29_1() {
    const ctx = document.getElementById('chart_29_1');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Flood Risk',
                data: properties.map(p => p.naturalDisasters.floodRisk),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Risk Level: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 142: Hurricane/Wind Risk
function createChart_29_2() {
    const ctx = document.getElementById('chart_29_2');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Hurricane/Wind Risk',
                data: properties.map(p => p.naturalDisasters.hurricaneWindRisk),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Risk Level: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 143: Earthquake Risk
function createChart_29_3() {
    const ctx = document.getElementById('chart_29_3');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Earthquake Risk',
                data: properties.map(p => p.naturalDisasters.earthquakeRisk),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Risk Level: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 144: Wildfire Risk
function createChart_29_4() {
    const ctx = document.getElementById('chart_29_4');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Wildfire Risk',
                data: properties.map(p => p.naturalDisasters.wildfireRisk),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Risk Level: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 145: Overall Disaster Risk Score
function createChart_29_5() {
    const ctx = document.getElementById('chart_29_5');
    
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Flood', 'Hurricane/Wind', 'Earthquake', 'Wildfire'],
            datasets: properties.map((property, index) => ({
                label: property.name,
                data: [
                    property.naturalDisasters.floodRisk,
                    property.naturalDisasters.hurricaneWindRisk,
                    property.naturalDisasters.earthquakeRisk,
                    property.naturalDisasters.wildfireRisk
                ],
                backgroundColor: property.color + '20',
                borderColor: property.color,
                borderWidth: 2,
                pointBackgroundColor: property.color,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        font: {
                            family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                            size: 12
                        },
                        padding: 20
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        backdropColor: 'transparent',
                        stepSize: 20
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    pointLabels: {
                        color: '#ffffff',
                        font: {
                            size: 12
                        }
                    }
                }
            }
        }
    });
}

// CATEGORY 30: ACCESSIBILITY
// ============================================

// Chart 146: Wheelchair Accessibility Score
function createChart_30_1() {
    const ctx = document.getElementById('chart_30_1');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Wheelchair Accessibility',
                data: properties.map(p => p.accessibility.wheelchairAccessibilityScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Score: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 147: Public Transit Proximity
function createChart_30_2() {
    const ctx = document.getElementById('chart_30_2');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Distance to Transit',
                data: properties.map(p => p.accessibility.publicTransitProximity),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y + ' miles';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + ' mi';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 148: Walkability Score
function createChart_30_3() {
    const ctx = document.getElementById('chart_30_3');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Walkability',
                data: properties.map(p => p.accessibility.walkabilityScore),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Score: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 149: Bike-Friendliness Rating
function createChart_30_4() {
    const ctx = document.getElementById('chart_30_4');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Bike-Friendliness',
                data: properties.map(p => p.accessibility.bikeFriendlinessRating),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Rating: ' + context.parsed.y + '/100';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#b8c5d6',
                        callback: function(value) {
                            return value + '/100';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Chart 150: Universal Design Features
function createChart_30_5() {
    const ctx = document.getElementById('chart_30_5');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Universal Design Features',
                data: properties.map(p => p.accessibility.universalDesignFeatures),
                backgroundColor: properties.map(p => p.color),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y + ' features';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#b8c5d6',
                        stepSize: 2,
                        callback: function(value) {
                            return value + ' features';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#b8c5d6'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}
