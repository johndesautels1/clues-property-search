// ============================================
// BATCH 6 DATA APPEND
// Categories 26-30 Data for All 3 Properties
// ============================================

// Add these fields to Property A (Luxury Penthouse):
{
    // CATEGORY 26: HISTORICAL DATA
    historicalData: {
        valueHistory: {
            years: ['2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024'],
            values: [850000, 920000, 980000, 1050000, 1150000, 1280000, 1420000, 1580000, 1750000, 1950000]
        },
        previousSales: {
            dates: ['2010', '2015', '2020'],
            prices: [650000, 850000, 1280000]
        },
        timeOnMarket: {
            years: ['2010', '2015', '2020'],
            days: [45, 32, 18]
        },
        ownerHistory: {
            owners: ['Developer', 'Investor Group', 'Private Owner', 'Current Owner'],
            years: [2008, 2010, 2015, 2020]
        },
        renovationTimeline: {
            years: ['2012', '2016', '2019', '2022'],
            projects: ['Kitchen Upgrade', 'Smart Home Install', 'Bathroom Remodel', 'HVAC Replacement'],
            costs: [45000, 85000, 95000, 42000]
        }
    },
    
    // CATEGORY 27: RESALE POTENTIAL
    resalePotential: {
        projectedValue5Year: 2450000,
        marketDemandScore: 94,
        daysToSellEstimate: 28,
        buyerPoolSize: 1250,
        desirabilityIndex: 96
    },
    
    // CATEGORY 28: LIFESTYLE FIT
    lifestyleFit: {
        overallMatchScore: 92,
        workLifeBalanceRating: 88,
        entertainmentOptionsScore: 95,
        culturalFitRating: 91,
        climatePreferenceMatch: 85
    },
    
    // CATEGORY 29: NATURAL DISASTERS
    naturalDisasters: {
        floodRisk: 15,
        hurricaneWindRisk: 45,
        earthquakeRisk: 8,
        wildfireRisk: 5,
        overallDisasterRisk: 18
    },
    
    // CATEGORY 30: ACCESSIBILITY
    accessibility: {
        wheelchairAccessibilityScore: 95,
        publicTransitProximity: 0.3,
        walkabilityScore: 98,
        bikeFriendlinessRating: 92,
        universalDesignFeatures: 18
    }
}

// Add these fields to Property B (Suburban Family Home):
{
    // CATEGORY 26: HISTORICAL DATA
    historicalData: {
        valueHistory: {
            years: ['2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024'],
            values: [420000, 445000, 465000, 490000, 525000, 580000, 640000, 695000, 735000, 785000]
        },
        previousSales: {
            dates: ['2008', '2012', '2018'],
            prices: [325000, 395000, 490000]
        },
        timeOnMarket: {
            years: ['2008', '2012', '2018'],
            days: [62, 48, 35]
        },
        ownerHistory: {
            owners: ['Builder', 'First Family', 'Second Family', 'Current Owner'],
            years: [2006, 2008, 2012, 2018]
        },
        renovationTimeline: {
            years: ['2010', '2014', '2019', '2023'],
            projects: ['Deck Addition', 'Master Suite', 'Kitchen Remodel', 'Roof Replacement'],
            costs: [28000, 65000, 52000, 18000]
        }
    },
    
    // CATEGORY 27: RESALE POTENTIAL
    resalePotential: {
        projectedValue5Year: 985000,
        marketDemandScore: 88,
        daysToSellEstimate: 42,
        buyerPoolSize: 3450,
        desirabilityIndex: 89
    },
    
    // CATEGORY 28: LIFESTYLE FIT
    lifestyleFit: {
        overallMatchScore: 94,
        workLifeBalanceRating: 96,
        entertainmentOptionsScore: 78,
        culturalFitRating: 82,
        climatePreferenceMatch: 92
    },
    
    // CATEGORY 29: NATURAL DISASTERS
    naturalDisasters: {
        floodRisk: 8,
        hurricaneWindRisk: 22,
        earthquakeRisk: 12,
        wildfireRisk: 18,
        overallDisasterRisk: 15
    },
    
    // CATEGORY 30: ACCESSIBILITY
    accessibility: {
        wheelchairAccessibilityScore: 72,
        publicTransitProximity: 2.8,
        walkabilityScore: 65,
        bikeFriendlinessRating: 58,
        universalDesignFeatures: 8
    }
}

// Add these fields to Property C (Investment Condo):
{
    // CATEGORY 26: HISTORICAL DATA
    historicalData: {
        valueHistory: {
            years: ['2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024'],
            values: [285000, 298000, 315000, 335000, 358000, 395000, 435000, 472000, 505000, 545000]
        },
        previousSales: {
            dates: ['2011', '2016', '2021'],
            prices: [235000, 298000, 435000]
        },
        timeOnMarket: {
            years: ['2011', '2016', '2021'],
            days: [72, 55, 38]
        },
        ownerHistory: {
            owners: ['Developer', 'Investor A', 'Investor B', 'Current Investor'],
            years: [2009, 2011, 2016, 2021]
        },
        renovationTimeline: {
            years: ['2013', '2017', '2022'],
            projects: ['Flooring Update', 'Appliance Upgrade', 'Paint & Fixtures'],
            costs: [12000, 18000, 8500]
        }
    },
    
    // CATEGORY 27: RESALE POTENTIAL
    resalePotential: {
        projectedValue5Year: 695000,
        marketDemandScore: 82,
        daysToSellEstimate: 58,
        buyerPoolSize: 2890,
        desirabilityIndex: 81
    },
    
    // CATEGORY 28: LIFESTYLE FIT
    lifestyleFit: {
        overallMatchScore: 76,
        workLifeBalanceRating: 82,
        entertainmentOptionsScore: 88,
        culturalFitRating: 79,
        climatePreferenceMatch: 81
    },
    
    // CATEGORY 29: NATURAL DISASTERS
    naturalDisasters: {
        floodRisk: 25,
        hurricaneWindRisk: 38,
        earthquakeRisk: 6,
        wildfireRisk: 12,
        overallDisasterRisk: 20
    },
    
    // CATEGORY 30: ACCESSIBILITY
    accessibility: {
        wheelchairAccessibilityScore: 85,
        publicTransitProximity: 0.8,
        walkabilityScore: 88,
        bikeFriendlinessRating: 82,
        universalDesignFeatures: 12
    }
}
