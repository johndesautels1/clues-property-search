// 🏠 Property Comparison Dashboard - Data File
// CONVERSATION ID: PROPERTY-VIZ-SESSION-001
// Data is easily editable - modify property values below

const properties = [
    {
        id: "A",
        name: "Gulf Towers 202",
        address: "290 41st Ave #202, St. Pete Beach, FL 33706",
        type: "Condo",
        color: "#d4af37", // Gold
        
        // Category 1: Price & Value
        price: 775000,
        listPrice: 775000,
        pricePerSqFt: 540.28,
        hoaFee: 817,
        hoaFrequency: "monthly",
        taxesAnnual: 8547,
        insuranceAnnual: 3600,
        totalMonthlyCost: 5529,
        
        // Category 2: Size & Dimensions
        sqFtTotal: 1434,
        sqFtLiving: 1434,
        lotSize: 0, // Condo
        lotSizeAcres: 0,
        bedrooms: 2,
        bathrooms: 2,
        bathroomsFull: 2,
        bathroomsHalf: 0,
        
        // Category 3: Bedrooms & Bathrooms
        primarySuite: {
            hasSuite: true,
            hasWalkInCloset: true,
            hasEnsuite: true,
            size: 180,
            features: ["Gulf View", "Walk-in Closet", "Private Bath"]
        },
        bedroomSizes: [180, 144], // sqft
        bathroomDetails: {
            full: 2,
            half: 0,
            ensuites: 1,
            updated: true
        },
        
        // Category 4: Location & Access
        location: {
            distanceToBeach: 0.1, // miles
            beachAccess: "Direct",
            commuteDowntown: 25, // minutes
            walkScore: 72,
            bikeScore: 68,
            transitScore: 35,
            nearbyAmenities: {
                groceryStores: 0.8,
                restaurants: 0.3,
                schools: 2.1,
                parks: 0.2,
                shopping: 1.5
            }
        },
        
        // Category 5: Property Age & Condition
        yearBuilt: 2006,
        age: 18,
        lastRenovation: 2019,
        recentUpdates: ["Kitchen", "Bathrooms", "Flooring"],
        condition: "Excellent",
        renovationQuality: 9,
        
        // Category 6: Interior Features
        interiorFeatures: {
            condition: "Excellent",
            flooring: "Porcelain Tile, LVP",
            kitchenFeatures: "Quartz, Soft-Close, Island",
            hasRefrigerator: true,
            hasDishwasher: true,
            hasRange: true,
            hasMicrowave: true,
            hasWasher: true,
            hasDryer: true,
            hasDisposal: true,
            applianceCount: 7,
            hasFireplace: false,
            fireplaceCount: 0,
            laundryType: "In-Unit",
            hasCathedralCeilings: false,
            hasWalkInCloset: true,
            primaryBRMainFloor: true,
            hasOpenFloorPlan: true,
            hasCrownMolding: true,
            hasWetBar: false,
            featureCount: 6
        },
        
        // Category 7: Exterior & Outdoor
        exteriorFeatures: {
            hasPool: true,
            poolType: "Community",
            deckPatio: "Balcony w/ Gulf View",
            fenceType: "None",
            landscaping: "HOA Maintained",
            viewType: "Gulf/Beach",
            hasBalcony: true,
            hasOutdoorShower: true,
            hasHurricaneProtection: true,
            hurricaneType: "Impact Windows",
            hasSprinklerSystem: false,
            hasOutdoorKitchen: false,
            hasPrivateDock: false,
            frontExposure: "West (Gulf)",
            featureCount: 5
        },
        
        // Category 8: Parking & Garage
        parking: {
            garageSpaces: 0,
            hasAttachedGarage: false,
            garageType: "N/A",
            hasCarport: false,
            carportSpaces: 0,
            totalParking: 2,
            assignedSpaces: 2,
            hasDriveway: false,
            hasCoveredParking: true,
            hasGuestParking: true,
            hasGarageDoorOpener: false,
            totalCoveredParking: 1
        },
        
        // Category 9: Building Details (Condo-specific)
        buildingDetails: {
            buildingName: "Gulf Towers",
            buildingTotalFloors: 8,
            floorNumber: 2,
            floorPosition: 0.25, // 25% = lower floors
            floorsInUnit: 1,
            hasElevator: true,
            communityAmenities: ["Pool", "Fitness Center", "Beach Access", "Storage"]
        },
        
        // Category 10: Waterfront & Views
        waterfront: {
            hasWaterFrontage: false,
            waterfrontFeet: 0,
            hasWaterAccess: true,
            waterAccessType: "Beach",
            hasWaterView: true,
            waterViewType: "Gulf View",
            waterBodyName: "Gulf of Mexico",
            viewType: "Gulf/Beach",
            viewQuality: 10,
            pricePerWaterfrontFt: 0
        }
    },
    
    {
        id: "B",
        name: "Roxborough Park Estate",
        address: "8927 Tappy Toorie Circle, Littleton, CO 80125",
        type: "Single Family",
        color: "#4a9eff", // Blue
        
        // Category 1: Price & Value
        price: 1250000,
        listPrice: 1250000,
        pricePerSqFt: 298.51,
        hoaFee: 95,
        hoaFrequency: "monthly",
        taxesAnnual: 7200,
        insuranceAnnual: 2400,
        totalMonthlyCost: 7295,
        
        // Category 2: Size & Dimensions
        sqFtTotal: 4187,
        sqFtLiving: 4187,
        lotSize: 12850,
        lotSizeAcres: 0.295,
        bedrooms: 5,
        bathrooms: 4,
        bathroomsFull: 3,
        bathroomsHalf: 1,
        
        // Category 3: Bedrooms & Bathrooms
        primarySuite: {
            hasSuite: true,
            hasWalkInCloset: true,
            hasEnsuite: true,
            size: 420,
            features: ["Mountain View", "5-Piece Bath", "Sitting Area", "Fireplace"]
        },
        bedroomSizes: [420, 240, 220, 200, 180],
        bathroomDetails: {
            full: 3,
            half: 1,
            ensuites: 2,
            updated: true
        },
        
        // Category 4: Location & Access
        location: {
            distanceToBeach: 0, // No beach
            beachAccess: "N/A",
            commuteDowntown: 35,
            walkScore: 28,
            bikeScore: 45,
            transitScore: 18,
            nearbyAmenities: {
                groceryStores: 2.5,
                restaurants: 2.8,
                schools: 1.2,
                parks: 0.8,
                shopping: 3.5
            }
        },
        
        // Category 5: Property Age & Condition
        yearBuilt: 2002,
        age: 22,
        lastRenovation: 2018,
        recentUpdates: ["Roof", "HVAC", "Kitchen", "Primary Bath"],
        condition: "Excellent",
        renovationQuality: 9,
        
        // Category 6: Interior Features
        interiorFeatures: {
            condition: "Excellent",
            flooring: "Hardwood, Tile, Carpet",
            kitchenFeatures: "Granite, Cherry Cabinets, Gas Range, Double Oven",
            hasRefrigerator: true,
            hasDishwasher: true,
            hasRange: true,
            hasMicrowave: true,
            hasWasher: true,
            hasDryer: true,
            hasDisposal: true,
            applianceCount: 7,
            hasFireplace: true,
            fireplaceCount: 2,
            laundryType: "Main Floor",
            hasCathedralCeilings: true,
            hasWalkInCloset: true,
            primaryBRMainFloor: false,
            hasOpenFloorPlan: true,
            hasCrownMolding: true,
            hasWetBar: true,
            featureCount: 10
        },
        
        // Category 7: Exterior & Outdoor
        exteriorFeatures: {
            hasPool: false,
            poolType: "N/A",
            deckPatio: "Deck, Covered Patio",
            fenceType: "Wood Privacy",
            landscaping: "Professional",
            viewType: "Mountain/Golf Course",
            hasBalcony: false,
            hasOutdoorShower: false,
            hasHurricaneProtection: false,
            hurricaneType: "N/A",
            hasSprinklerSystem: true,
            hasOutdoorKitchen: false,
            hasPrivateDock: false,
            frontExposure: "South",
            featureCount: 4
        },
        
        // Category 8: Parking & Garage
        parking: {
            garageSpaces: 3,
            hasAttachedGarage: true,
            garageType: "3-Car Attached",
            hasCarport: false,
            carportSpaces: 0,
            totalParking: 5,
            assignedSpaces: 3,
            hasDriveway: true,
            hasCoveredParking: true,
            hasGuestParking: true,
            hasGarageDoorOpener: true,
            totalCoveredParking: 3
        },
        
        // Category 9: Building Details
        buildingDetails: {
            buildingName: "N/A",
            buildingTotalFloors: 2,
            floorNumber: 1,
            floorPosition: 1.0, // Single family home
            floorsInUnit: 2,
            hasElevator: false,
            communityAmenities: ["Golf Course", "Clubhouse", "Tennis Courts", "Parks"]
        },
        
        // Category 10: Waterfront & Views
        waterfront: {
            hasWaterFrontage: false,
            waterfrontFeet: 0,
            hasWaterAccess: false,
            waterAccessType: "N/A",
            hasWaterView: false,
            waterViewType: "Mountain/Golf",
            waterBodyName: "N/A",
            viewType: "Mountain/Golf Course",
            viewQuality: 8,
            pricePerWaterfrontFt: 0
        }
    },
    
    {
        id: "C",
        name: "Sunset Bay Townhome",
        address: "456 Bayfront Lane, St. Pete Beach, FL 33706",
        type: "Townhome",
        color: "#b76e79", // Rose Gold
        
        // Category 1: Price & Value
        price: 625000,
        listPrice: 625000,
        pricePerSqFt: 347.22,
        hoaFee: 425,
        hoaFrequency: "monthly",
        taxesAnnual: 6850,
        insuranceAnnual: 2800,
        totalMonthlyCost: 4566,
        
        // Category 2: Size & Dimensions
        sqFtTotal: 1800,
        sqFtLiving: 1800,
        lotSize: 2200,
        lotSizeAcres: 0.05,
        bedrooms: 3,
        bathrooms: 2.5,
        bathroomsFull: 2,
        bathroomsHalf: 1,
        
        // Category 3: Bedrooms & Bathrooms
        primarySuite: {
            hasSuite: true,
            hasWalkInCloset: true,
            hasEnsuite: true,
            size: 280,
            features: ["Bay View", "Walk-in Closet", "Soaking Tub"]
        },
        bedroomSizes: [280, 165, 150],
        bathroomDetails: {
            full: 2,
            half: 1,
            ensuites: 1,
            updated: false
        },
        
        // Category 4: Location & Access
        location: {
            distanceToBeach: 0.3,
            beachAccess: "Community",
            commuteDowntown: 22,
            walkScore: 65,
            bikeScore: 62,
            transitScore: 38,
            nearbyAmenities: {
                groceryStores: 1.2,
                restaurants: 0.5,
                schools: 1.8,
                parks: 0.4,
                shopping: 1.8
            }
        },
        
        // Category 5: Property Age & Condition
        yearBuilt: 2015,
        age: 9,
        lastRenovation: 2021,
        recentUpdates: ["Paint", "Appliances"],
        condition: "Good",
        renovationQuality: 7,
        
        // Category 6: Interior Features
        interiorFeatures: {
            condition: "Good",
            flooring: "Laminate, Tile",
            kitchenFeatures: "Granite, Stainless Appliances",
            hasRefrigerator: true,
            hasDishwasher: true,
            hasRange: true,
            hasMicrowave: true,
            hasWasher: true,
            hasDryer: true,
            hasDisposal: true,
            applianceCount: 7,
            hasFireplace: false,
            fireplaceCount: 0,
            laundryType: "Second Floor",
            hasCathedralCeilings: false,
            hasWalkInCloset: true,
            primaryBRMainFloor: false,
            hasOpenFloorPlan: true,
            hasCrownMolding: false,
            hasWetBar: false,
            featureCount: 4
        },
        
        // Category 7: Exterior & Outdoor
        exteriorFeatures: {
            hasPool: true,
            poolType: "Community",
            deckPatio: "Private Patio",
            fenceType: "Privacy",
            landscaping: "HOA Maintained",
            viewType: "Bay",
            hasBalcony: true,
            hasOutdoorShower: false,
            hasHurricaneProtection: true,
            hurricaneType: "Storm Shutters",
            hasSprinklerSystem: false,
            hasOutdoorKitchen: false,
            hasPrivateDock: false,
            frontExposure: "East",
            featureCount: 5
        },
        
        // Category 8: Parking & Garage
        parking: {
            garageSpaces: 1,
            hasAttachedGarage: true,
            garageType: "1-Car Attached",
            hasCarport: false,
            carportSpaces: 0,
            totalParking: 2,
            assignedSpaces: 1,
            hasDriveway: true,
            hasCoveredParking: true,
            hasGuestParking: true,
            hasGarageDoorOpener: true,
            totalCoveredParking: 1
        },
        
        // Category 9: Building Details
        buildingDetails: {
            buildingName: "Sunset Bay",
            buildingTotalFloors: 2,
            floorNumber: 1,
            floorPosition: 0.5, // Townhome
            floorsInUnit: 2,
            hasElevator: false,
            communityAmenities: ["Pool", "Dock", "Clubhouse"]
        },
        
        // Category 10: Waterfront & Views
        waterfront: {
            hasWaterFrontage: true,
            waterfrontFeet: 45,
            hasWaterAccess: true,
            waterAccessType: "Community Dock",
            hasWaterView: true,
            waterViewType: "Bay View",
            waterBodyName: "Boca Ciega Bay",
            viewType: "Bay",
            viewQuality: 7,
            pricePerWaterfrontFt: 13888.89
        }
    }
];
