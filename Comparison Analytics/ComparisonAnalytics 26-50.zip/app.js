// 📊 Property Comparison Dashboard - Chart Engine
// CONVERSATION ID: PROPERTY-VIZ-SESSION-001
// All visualizations pull data dynamically from data.js

// Chart.js default configuration
Chart.defaults.color = '#b8c5d6';
Chart.defaults.font.family = "'Helvetica Neue', Arial, sans-serif";
Chart.defaults.plugins.legend.labels.usePointStyle = true;

// =============================================================================
// CATEGORY 1: PRICE & VALUE (Placeholders - Batch 1)
// =============================================================================

function createChart_1_1() {
    const ctx = document.getElementById('chart_1_1').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'List Price',
                data: properties.map(p => p.price),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => '$' + value.toLocaleString()
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: ctx => '$' + ctx.parsed.y.toLocaleString()
                    }
                }
            }
        }
    });
}

function createChart_1_2() {
    const ctx = document.getElementById('chart_1_2').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Price/SqFt',
                data: properties.map(p => p.pricePerSqFt),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => '$' + value.toFixed(2)
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false }
            }
        }
    });
}

function createChart_1_3() {
    const ctx = document.getElementById('chart_1_3').getContext('2d');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Price Value', 'Size Value', 'Location', 'Condition', 'Features'],
            datasets: properties.map(p => ({
                label: p.name,
                data: [
                    100 - (p.pricePerSqFt / 6),
                    p.sqFtTotal / 50,
                    p.location.walkScore,
                    p.renovationQuality * 10,
                    p.interiorFeatures.featureCount * 10
                ],
                borderColor: p.color,
                backgroundColor: p.color + '40',
                pointBackgroundColor: p.color
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { stepSize: 20 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

function createChart_1_4() {
    const ctx = document.getElementById('chart_1_4').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Monthly HOA Fee',
                data: properties.map(p => p.hoaFee),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => '$' + value.toLocaleString()
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function createChart_1_5() {
    const ctx = document.getElementById('chart_1_5').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Total Monthly Cost',
                data: properties.map(p => p.totalMonthlyCost),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => '$' + value.toLocaleString()
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                y: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

// =============================================================================
// CATEGORY 2: SIZE & DIMENSIONS (Placeholders - Batch 1)
// =============================================================================

function createChart_2_1() {
    const ctx = document.getElementById('chart_2_1').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Total SqFt',
                data: properties.map(p => p.sqFtTotal),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function createChart_2_2() {
    const ctx = document.getElementById('chart_2_2').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Living Area',
                data: properties.map(p => p.sqFtLiving),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function createChart_2_3() {
    const ctx = document.getElementById('chart_2_3').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Lot Size (SqFt)',
                data: properties.map(p => p.lotSize),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function createChart_2_4() {
    const ctx = document.getElementById('chart_2_4').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Bedrooms',
                    data: properties.map(p => p.bedrooms),
                    backgroundColor: '#d4af37',
                    borderColor: '#d4af37',
                    borderWidth: 2
                },
                {
                    label: 'Bathrooms',
                    data: properties.map(p => p.bathrooms),
                    backgroundColor: '#4a9eff',
                    borderColor: '#4a9eff',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            }
        }
    });
}

function createChart_2_5() {
    const ctx = document.getElementById('chart_2_5').getContext('2d');
    const efficiencyData = properties.map(p => ({
        name: p.name,
        ratio: p.lotSize > 0 ? (p.sqFtTotal / p.lotSize * 100).toFixed(1) : 100,
        color: p.color
    }));
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: efficiencyData.map(d => d.name),
            datasets: [{
                data: efficiencyData.map(d => d.ratio),
                backgroundColor: efficiencyData.map(d => d.color + '80'),
                borderColor: efficiencyData.map(d => d.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        label: ctx => ctx.label + ': ' + ctx.parsed + '%'
                    }
                }
            }
        }
    });
}

// =============================================================================
// CATEGORY 3: BEDROOMS & BATHROOMS (Placeholders - Batch 1)
// =============================================================================

function createChart_3_1() {
    const ctx = document.getElementById('chart_3_1').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Bedrooms',
                data: properties.map(p => p.bedrooms),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function createChart_3_2() {
    const ctx = document.getElementById('chart_3_2').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Full Baths',
                    data: properties.map(p => p.bathroomsFull),
                    backgroundColor: '#d4af37',
                    borderWidth: 2
                },
                {
                    label: 'Half Baths',
                    data: properties.map(p => p.bathroomsHalf),
                    backgroundColor: '#4a9eff',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    stacked: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: {
                    stacked: true,
                    grid: { display: false }
                }
            }
        }
    });
}

function createChart_3_3() {
    const ctx = document.getElementById('chart_3_3').getContext('2d');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Has Suite', 'Walk-in Closet', 'Ensuite Bath', 'Size', 'Features'],
            datasets: properties.map(p => ({
                label: p.name,
                data: [
                    p.primarySuite.hasSuite ? 100 : 0,
                    p.primarySuite.hasWalkInCloset ? 100 : 0,
                    p.primarySuite.hasEnsuite ? 100 : 0,
                    (p.primarySuite.size / 5),
                    (p.primarySuite.features.length * 33.3)
                ],
                borderColor: p.color,
                backgroundColor: p.color + '40',
                pointBackgroundColor: p.color
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

function createChart_3_4() {
    const ctx = document.getElementById('chart_3_4').getContext('2d');
    const maxSize = Math.max(...properties.flatMap(p => p.bedroomSizes));
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Avg Bedroom Size',
                data: properties.map(p => {
                    const sum = p.bedroomSizes.reduce((a, b) => a + b, 0);
                    return Math.round(sum / p.bedroomSizes.length);
                }),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: ctx => ctx.parsed.y + ' sq ft'
                    }
                }
            }
        }
    });
}

function createChart_3_5() {
    const ctx = document.getElementById('chart_3_5').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Bath-to-Bedroom Ratio',
                data: properties.map(p => (p.bathrooms / p.bedrooms).toFixed(2)),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

// =============================================================================
// CATEGORY 4: LOCATION & ACCESS (Placeholders - Batch 1)
// =============================================================================

function createChart_4_1() {
    const ctx = document.getElementById('chart_4_1').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Distance to Beach (miles)',
                data: properties.map(p => p.location.distanceToBeach),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                y: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function createChart_4_2() {
    const ctx = document.getElementById('chart_4_2').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Commute Time (minutes)',
                data: properties.map(p => p.location.commuteDowntown),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function createChart_4_3() {
    const ctx = document.getElementById('chart_4_3').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Walk Score',
                    data: properties.map(p => p.location.walkScore),
                    backgroundColor: '#d4af37',
                    borderWidth: 2
                },
                {
                    label: 'Bike Score',
                    data: properties.map(p => p.location.bikeScore),
                    backgroundColor: '#4a9eff',
                    borderWidth: 2
                },
                {
                    label: 'Transit Score',
                    data: properties.map(p => p.location.transitScore),
                    backgroundColor: '#b76e79',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            }
        }
    });
}

function createChart_4_4() {
    const ctx = document.getElementById('chart_4_4').getContext('2d');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Grocery', 'Restaurants', 'Schools', 'Parks', 'Shopping'],
            datasets: properties.map(p => ({
                label: p.name,
                data: [
                    Math.max(0, 100 - (p.location.nearbyAmenities.groceryStores * 20)),
                    Math.max(0, 100 - (p.location.nearbyAmenities.restaurants * 20)),
                    Math.max(0, 100 - (p.location.nearbyAmenities.schools * 20)),
                    Math.max(0, 100 - (p.location.nearbyAmenities.parks * 20)),
                    Math.max(0, 100 - (p.location.nearbyAmenities.shopping * 20))
                ],
                borderColor: p.color,
                backgroundColor: p.color + '40',
                pointBackgroundColor: p.color
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });
}

function createChart_4_5() {
    const ctx = document.getElementById('chart_4_5').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Location Score',
                data: properties.map(p => {
                    const walkScore = p.location.walkScore;
                    const beachScore = p.location.distanceToBeach === 0 ? 0 : Math.max(0, 100 - (p.location.distanceToBeach * 50));
                    return Math.round((walkScore + beachScore) / 2);
                }),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

// =============================================================================
// CATEGORY 5: PROPERTY AGE & CONDITION (Placeholders - Batch 1)
// =============================================================================

function createChart_5_1() {
    const ctx = document.getElementById('chart_5_1').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Year Built',
                data: properties.map(p => p.yearBuilt),
                borderColor: '#d4af37',
                backgroundColor: '#d4af3740',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    min: 2000,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            }
        }
    });
}

function createChart_5_2() {
    const ctx = document.getElementById('chart_5_2').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Property Age (years)',
                data: properties.map(p => p.age),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                y: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function createChart_5_3() {
    const ctx = document.getElementById('chart_5_3').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Last Renovation Year',
                data: properties.map(p => p.lastRenovation),
                borderColor: '#4a9eff',
                backgroundColor: '#4a9eff40',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    min: 2015,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            }
        }
    });
}

function createChart_5_4() {
    const ctx = document.getElementById('chart_5_4').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Renovation Quality (1-10)',
                data: properties.map(p => p.renovationQuality),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10,
                    ticks: { stepSize: 1 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function createChart_5_5() {
    const ctx = document.getElementById('chart_5_5').getContext('2d');
    const conditionMap = { 'Excellent': 10, 'Good': 7, 'Fair': 5, 'Poor': 3 };
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name + ' - ' + p.condition),
            datasets: [{
                data: properties.map(p => conditionMap[p.condition]),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}

// =============================================================================
// CATEGORY 6: INTERIOR FEATURES - BATCH 2 START
// =============================================================================

function createChart_6_1() {
    const ctx = document.getElementById('chart_6_1').getContext('2d');
    
    // Interior features checklist comparison
    const features = [
        'Fireplace',
        'Walk-in Closet',
        'Open Floor Plan',
        'Crown Molding',
        'Wet Bar',
        'Cathedral Ceilings',
        'Primary BR Main Floor'
    ];
    
    const datasets = properties.map(p => ({
        label: p.name,
        data: [
            p.interiorFeatures.hasFireplace ? 1 : 0,
            p.interiorFeatures.hasWalkInCloset ? 1 : 0,
            p.interiorFeatures.hasOpenFloorPlan ? 1 : 0,
            p.interiorFeatures.hasCrownMolding ? 1 : 0,
            p.interiorFeatures.hasWetBar ? 1 : 0,
            p.interiorFeatures.hasCathedralCeilings ? 1 : 0,
            p.interiorFeatures.primaryBRMainFloor ? 1 : 0
        ],
        backgroundColor: p.color + '80',
        borderColor: p.color,
        borderWidth: 2
    }));
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: features,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 1,
                    ticks: {
                        stepSize: 1,
                        callback: value => value === 1 ? 'Yes' : 'No'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { 
                    grid: { display: false },
                    ticks: { maxRotation: 45, minRotation: 45 }
                }
            },
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        label: ctx => ctx.dataset.label + ': ' + (ctx.parsed.y === 1 ? 'Yes' : 'No')
                    }
                }
            }
        }
    });
}

function createChart_6_2() {
    const ctx = document.getElementById('chart_6_2').getContext('2d');
    
    // 7-appliance comparison
    const appliances = [
        'Refrigerator',
        'Dishwasher',
        'Range',
        'Microwave',
        'Washer',
        'Dryer',
        'Disposal'
    ];
    
    const datasets = properties.map(p => ({
        label: p.name,
        data: [
            p.interiorFeatures.hasRefrigerator ? 1 : 0,
            p.interiorFeatures.hasDishwasher ? 1 : 0,
            p.interiorFeatures.hasRange ? 1 : 0,
            p.interiorFeatures.hasMicrowave ? 1 : 0,
            p.interiorFeatures.hasWasher ? 1 : 0,
            p.interiorFeatures.hasDryer ? 1 : 0,
            p.interiorFeatures.hasDisposal ? 1 : 0
        ],
        backgroundColor: p.color + '80',
        borderColor: p.color,
        borderWidth: 2
    }));
    
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: appliances,
            datasets: datasets.map(d => ({
                ...d,
                data: d.data.map(v => v * 100),
                backgroundColor: d.backgroundColor.replace('80', '40'),
                pointBackgroundColor: d.borderColor
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        stepSize: 50,
                        callback: value => value === 100 ? 'Yes' : value === 0 ? 'No' : ''
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            },
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}

function createChart_6_3() {
    const ctx = document.getElementById('chart_6_3').getContext('2d');
    
    // Quality ratings for kitchen and flooring
    const qualityMap = {
        'Excellent': 10,
        'Good': 7,
        'Fair': 5,
        'Poor': 3
    };
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Overall Condition',
                    data: properties.map(p => qualityMap[p.interiorFeatures.condition]),
                    backgroundColor: '#d4af3780',
                    borderColor: '#d4af37',
                    borderWidth: 2
                },
                {
                    label: 'Flooring Count',
                    data: properties.map(p => p.interiorFeatures.flooring.split(',').length),
                    backgroundColor: '#4a9eff80',
                    borderColor: '#4a9eff',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        afterLabel: (ctx) => {
                            if (ctx.datasetIndex === 0) {
                                return 'Condition: ' + properties[ctx.dataIndex].interiorFeatures.condition;
                            } else {
                                return 'Types: ' + properties[ctx.dataIndex].interiorFeatures.flooring;
                            }
                        }
                    }
                }
            }
        }
    });
}

function createChart_6_4() {
    const ctx = document.getElementById('chart_6_4').getContext('2d');
    
    // Total interior feature count comparison
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Total Interior Features',
                data: properties.map(p => p.interiorFeatures.featureCount),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { stepSize: 2 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                y: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: (ctx) => {
                            const features = [];
                            const p = properties[ctx.dataIndex].interiorFeatures;
                            if (p.hasFireplace) features.push('Fireplace (' + p.fireplaceCount + ')');
                            if (p.hasWalkInCloset) features.push('Walk-in Closet');
                            if (p.hasOpenFloorPlan) features.push('Open Floor Plan');
                            if (p.hasCrownMolding) features.push('Crown Molding');
                            if (p.hasWetBar) features.push('Wet Bar');
                            if (p.hasCathedralCeilings) features.push('Cathedral Ceilings');
                            return features.join(', ');
                        }
                    }
                }
            }
        }
    });
}

function createChart_6_5() {
    const ctx = document.getElementById('chart_6_5').getContext('2d');
    
    // Color-coded condition heatmap
    const conditionMap = {
        'Excellent': { value: 10, color: '#00ff00' },
        'Good': { value: 7, color: '#90ee90' },
        'Fair': { value: 5, color: '#ffff00' },
        'Poor': { value: 3, color: '#ff0000' }
    };
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name + ' - ' + p.interiorFeatures.condition),
            datasets: [{
                data: properties.map(p => conditionMap[p.interiorFeatures.condition].value),
                backgroundColor: properties.map(p => {
                    const cond = p.interiorFeatures.condition;
                    return conditionMap[cond].color + '80';
                }),
                borderColor: properties.map(p => {
                    const cond = p.interiorFeatures.condition;
                    return conditionMap[cond].color;
                }),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        generateLabels: (chart) => {
                            const data = chart.data;
                            return data.labels.map((label, i) => ({
                                text: label,
                                fillStyle: data.datasets[0].backgroundColor[i],
                                strokeStyle: data.datasets[0].borderColor[i],
                                lineWidth: 2,
                                hidden: false,
                                index: i
                            }));
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex];
                            return [
                                'Condition: ' + p.interiorFeatures.condition,
                                'Flooring: ' + p.interiorFeatures.flooring,
                                'Laundry: ' + p.interiorFeatures.laundryType
                            ];
                        }
                    }
                }
            }
        }
    });
}

// =============================================================================
// CATEGORY 7: EXTERIOR & OUTDOOR FEATURES - BATCH 2
// =============================================================================

function createChart_7_1() {
    const ctx = document.getElementById('chart_7_1').getContext('2d');
    
    // Pool and patio comparison
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Has Pool',
                    data: properties.map(p => p.exteriorFeatures.hasPool ? 1 : 0),
                    backgroundColor: '#d4af3780',
                    borderColor: '#d4af37',
                    borderWidth: 2
                },
                {
                    label: 'Has Balcony/Patio',
                    data: properties.map(p => p.exteriorFeatures.hasBalcony ? 1 : 0),
                    backgroundColor: '#4a9eff80',
                    borderColor: '#4a9eff',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 1,
                    ticks: {
                        stepSize: 1,
                        callback: value => value === 1 ? 'Yes' : 'No'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex];
                            if (ctx.datasetIndex === 0) {
                                return 'Pool: ' + (p.exteriorFeatures.hasPool ? p.exteriorFeatures.poolType : 'None');
                            } else {
                                return 'Outdoor Space: ' + p.exteriorFeatures.deckPatio;
                            }
                        }
                    }
                }
            }
        }
    });
}

function createChart_7_2() {
    const ctx = document.getElementById('chart_7_2').getContext('2d');
    
    // 7-feature outdoor amenities grid
    const features = [
        'Pool',
        'Balcony',
        'Outdoor Shower',
        'Hurricane Protection',
        'Sprinkler System',
        'Outdoor Kitchen',
        'Private Dock'
    ];
    
    const datasets = properties.map(p => ({
        label: p.name,
        data: [
            p.exteriorFeatures.hasPool ? 1 : 0,
            p.exteriorFeatures.hasBalcony ? 1 : 0,
            p.exteriorFeatures.hasOutdoorShower ? 1 : 0,
            p.exteriorFeatures.hasHurricaneProtection ? 1 : 0,
            p.exteriorFeatures.hasSprinklerSystem ? 1 : 0,
            p.exteriorFeatures.hasOutdoorKitchen ? 1 : 0,
            p.exteriorFeatures.hasPrivateDock ? 1 : 0
        ],
        backgroundColor: p.color + '80',
        borderColor: p.color,
        borderWidth: 2
    }));
    
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: features,
            datasets: datasets.map(d => ({
                ...d,
                data: d.data.map(v => v * 100),
                backgroundColor: d.backgroundColor.replace('80', '40'),
                pointBackgroundColor: d.borderColor
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        stepSize: 50,
                        callback: value => value === 100 ? 'Yes' : value === 0 ? 'No' : ''
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            },
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}

function createChart_7_3() {
    const ctx = document.getElementById('chart_7_3').getContext('2d');
    
    // View type quality comparison
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'View Type',
                data: properties.map(p => {
                    const viewMap = {
                        'Gulf/Beach': 10,
                        'Bay': 7,
                        'Mountain/Golf Course': 8,
                        'Mountain/Golf': 8,
                        'City': 5,
                        'Garden': 3,
                        'None': 0
                    };
                    return viewMap[p.exteriorFeatures.viewType] || 0;
                }),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10,
                    ticks: { stepSize: 2 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex];
                            return [
                                'View: ' + p.exteriorFeatures.viewType,
                                'Quality Score: ' + ctx.parsed.y + '/10',
                                'Exposure: ' + p.exteriorFeatures.frontExposure
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_7_4() {
    const ctx = document.getElementById('chart_7_4').getContext('2d');
    
    // Total exterior feature count
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Total Exterior Features',
                data: properties.map(p => p.exteriorFeatures.featureCount),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                y: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: (ctx) => {
                            const p = properties[ctx.dataIndex].exteriorFeatures;
                            const features = [];
                            if (p.hasPool) features.push('Pool');
                            if (p.hasBalcony) features.push('Balcony');
                            if (p.hasOutdoorShower) features.push('Outdoor Shower');
                            if (p.hasHurricaneProtection) features.push('Hurricane Protection');
                            if (p.hasSprinklerSystem) features.push('Sprinkler');
                            return features.join(', ');
                        }
                    }
                }
            }
        }
    });
}

function createChart_7_5() {
    const ctx = document.getElementById('chart_7_5').getContext('2d');
    
    // Landscaping quality ratings
    const landscapingMap = {
        'Professional': 10,
        'HOA Maintained': 8,
        'Basic': 5,
        'None': 0
    };
    
    new Chart(ctx, {
        type: 'polarArea',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Landscaping Quality',
                data: properties.map(p => landscapingMap[p.exteriorFeatures.landscaping] || 0),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 10,
                    ticks: { stepSize: 2 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            },
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex];
                            return [
                                p.name + ': ' + p.exteriorFeatures.landscaping,
                                'Quality: ' + ctx.parsed.r + '/10'
                            ];
                        }
                    }
                }
            }
        }
    });
}

// =============================================================================
// CATEGORY 8: PARKING & GARAGE - BATCH 2
// =============================================================================

function createChart_8_1() {
    const ctx = document.getElementById('chart_8_1').getContext('2d');
    
    // Total parking space comparison
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Garage Spaces',
                    data: properties.map(p => p.parking.garageSpaces),
                    backgroundColor: '#d4af3780',
                    borderColor: '#d4af37',
                    borderWidth: 2
                },
                {
                    label: 'Other Parking',
                    data: properties.map(p => p.parking.totalParking - p.parking.garageSpaces),
                    backgroundColor: '#4a9eff80',
                    borderColor: '#4a9eff',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    stacked: true,
                    ticks: { stepSize: 1 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: {
                    stacked: true,
                    grid: { display: false }
                }
            },
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        footer: (items) => {
                            const p = properties[items[0].dataIndex];
                            return 'Total Parking: ' + p.parking.totalParking + ' spaces';
                        }
                    }
                }
            }
        }
    });
}

function createChart_8_2() {
    const ctx = document.getElementById('chart_8_2').getContext('2d');
    
    // Garage type analysis
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name + ' - ' + p.parking.garageType),
            datasets: [{
                data: properties.map(p => p.parking.garageSpaces || 0.5),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        generateLabels: (chart) => {
                            const data = chart.data;
                            return data.labels.map((label, i) => ({
                                text: label,
                                fillStyle: data.datasets[0].backgroundColor[i],
                                strokeStyle: data.datasets[0].borderColor[i],
                                lineWidth: 2,
                                hidden: false,
                                index: i
                            }));
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex];
                            return [
                                'Garage Type: ' + p.parking.garageType,
                                'Garage Spaces: ' + p.parking.garageSpaces,
                                'Attached: ' + (p.parking.hasAttachedGarage ? 'Yes' : 'No')
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_8_3() {
    const ctx = document.getElementById('chart_8_3').getContext('2d');
    
    // Total covered parking
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Covered Parking Spaces',
                data: properties.map(p => p.parking.totalCoveredParking),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                y: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: (ctx) => {
                            const p = properties[ctx.dataIndex].parking;
                            return [
                                'Garage: ' + p.garageSpaces + ' spaces',
                                'Carport: ' + p.carportSpaces + ' spaces',
                                'Total: ' + p.totalParking + ' spaces'
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_8_4() {
    const ctx = document.getElementById('chart_8_4').getContext('2d');
    
    // Parking features matrix
    const features = [
        'Attached Garage',
        'Driveway',
        'Covered Parking',
        'Guest Parking',
        'Garage Door Opener'
    ];
    
    const datasets = properties.map(p => ({
        label: p.name,
        data: [
            p.parking.hasAttachedGarage ? 1 : 0,
            p.parking.hasDriveway ? 1 : 0,
            p.parking.hasCoveredParking ? 1 : 0,
            p.parking.hasGuestParking ? 1 : 0,
            p.parking.hasGarageDoorOpener ? 1 : 0
        ],
        backgroundColor: p.color + '80',
        borderColor: p.color,
        borderWidth: 2
    }));
    
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: features,
            datasets: datasets.map(d => ({
                ...d,
                data: d.data.map(v => v * 100),
                backgroundColor: d.backgroundColor.replace('80', '40'),
                pointBackgroundColor: d.borderColor
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        stepSize: 50,
                        callback: value => value === 100 ? 'Yes' : value === 0 ? 'No' : ''
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            },
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}

function createChart_8_5() {
    const ctx = document.getElementById('chart_8_5').getContext('2d');
    
    // Parking value analysis (price per parking space)
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Price Per Parking Space',
                data: properties.map(p => Math.round(p.price / p.parking.totalParking)),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => '$' + value.toLocaleString()
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex];
                            return [
                                'Price/Space: $' + ctx.parsed.y.toLocaleString(),
                                'Total Spaces: ' + p.parking.totalParking,
                                'Property Price: $' + p.price.toLocaleString()
                            ];
                        }
                    }
                }
            }
        }
    });
}

// =============================================================================
// CATEGORY 9: BUILDING DETAILS - BATCH 2
// =============================================================================

function createChart_9_1() {
    const ctx = document.getElementById('chart_9_1').getContext('2d');
    
    // Building floor analysis
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [
                {
                    label: 'Total Building Floors',
                    data: properties.map(p => p.buildingDetails.buildingTotalFloors),
                    backgroundColor: '#d4af3780',
                    borderColor: '#d4af37',
                    borderWidth: 2
                },
                {
                    label: 'Unit Floor Number',
                    data: properties.map(p => p.buildingDetails.floorNumber),
                    backgroundColor: '#4a9eff80',
                    borderColor: '#4a9eff',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 2 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        afterLabel: (ctx) => {
                            const p = properties[ctx.dataIndex].buildingDetails;
                            return [
                                'Building: ' + (p.buildingName || 'N/A'),
                                'Floor ' + p.floorNumber + ' of ' + p.buildingTotalFloors
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_9_2() {
    const ctx = document.getElementById('chart_9_2').getContext('2d');
    
    // Floor position comparison (vertical positioning as percentage)
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Floor Position (%)',
                data: properties.map(p => (p.buildingDetails.floorPosition * 100)),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: value => value + '%'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                y: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex].buildingDetails;
                            const position = ctx.parsed.x < 33 ? 'Lower Floors' : ctx.parsed.x < 67 ? 'Mid Floors' : 'Upper Floors';
                            return [
                                'Position: ' + ctx.parsed.x.toFixed(0) + '%',
                                'Classification: ' + position,
                                'Floor: ' + p.floorNumber + ' of ' + p.buildingTotalFloors
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_9_3() {
    const ctx = document.getElementById('chart_9_3').getContext('2d');
    
    // Elevator access
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name + ' - ' + (p.buildingDetails.hasElevator ? 'Elevator' : 'No Elevator')),
            datasets: [{
                data: properties.map(p => p.buildingDetails.hasElevator ? 1 : 0.5),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        generateLabels: (chart) => {
                            const data = chart.data;
                            return data.labels.map((label, i) => ({
                                text: label,
                                fillStyle: data.datasets[0].backgroundColor[i],
                                strokeStyle: data.datasets[0].borderColor[i],
                                lineWidth: 2,
                                hidden: false,
                                index: i
                            }));
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex].buildingDetails;
                            return [
                                'Elevator: ' + (p.hasElevator ? 'Yes' : 'No'),
                                'Floor: ' + p.floorNumber,
                                'Type: ' + properties[ctx.dataIndex].type
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_9_4() {
    const ctx = document.getElementById('chart_9_4').getContext('2d');
    
    // Unit layout (floors per unit)
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Floors in Unit',
                data: properties.map(p => p.buildingDetails.floorsInUnit),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 3,
                    ticks: { stepSize: 1 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex];
                            const layout = ctx.parsed.y === 1 ? 'Single-Level' : ctx.parsed.y === 2 ? 'Two-Story' : 'Multi-Level';
                            return [
                                'Layout: ' + layout,
                                'Floors: ' + ctx.parsed.y,
                                'Type: ' + p.type
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_9_5() {
    const ctx = document.getElementById('chart_9_5').getContext('2d');
    
    // Building amenities count
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Community Amenities',
                data: properties.map(p => p.buildingDetails.communityAmenities.length),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                y: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: (ctx) => {
                            const amenities = properties[ctx.dataIndex].buildingDetails.communityAmenities;
                            return 'Amenities: ' + amenities.join(', ');
                        }
                    }
                }
            }
        }
    });
}

// =============================================================================
// CATEGORY 10: WATERFRONT & VIEWS - BATCH 2
// =============================================================================

function createChart_10_1() {
    const ctx = document.getElementById('chart_10_1').getContext('2d');
    
    // Waterfront analysis (yes/no)
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name + ' - ' + (p.waterfront.hasWaterFrontage ? 'Waterfront' : 'No Waterfront')),
            datasets: [{
                data: properties.map(p => p.waterfront.hasWaterFrontage ? 1 : 0.5),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        generateLabels: (chart) => {
                            const data = chart.data;
                            return data.labels.map((label, i) => ({
                                text: label,
                                fillStyle: data.datasets[0].backgroundColor[i],
                                strokeStyle: data.datasets[0].borderColor[i],
                                lineWidth: 2,
                                hidden: false,
                                index: i
                            }));
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex].waterfront;
                            return [
                                'Waterfront: ' + (p.hasWaterFrontage ? 'Yes' : 'No'),
                                'Frontage: ' + p.waterfrontFeet + ' ft',
                                'Water Access: ' + (p.hasWaterAccess ? 'Yes' : 'No')
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_10_2() {
    const ctx = document.getElementById('chart_10_2').getContext('2d');
    
    // Water frontage comparison (linear feet)
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Waterfront Feet',
                data: properties.map(p => p.waterfront.waterfrontFeet),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value + ' ft'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                y: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex].waterfront;
                            return [
                                'Frontage: ' + ctx.parsed.x + ' ft',
                                'Water Body: ' + (p.waterBodyName || 'N/A'),
                                'Access: ' + p.waterAccessType
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_10_3() {
    const ctx = document.getElementById('chart_10_3').getContext('2d');
    
    // View quality matrix
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Water View', 'View Quality', 'Water Access', 'Waterfront', 'Value'],
            datasets: properties.map(p => ({
                label: p.name,
                data: [
                    p.waterfront.hasWaterView ? 100 : 0,
                    p.waterfront.viewQuality * 10,
                    p.waterfront.hasWaterAccess ? 100 : 0,
                    p.waterfront.hasWaterFrontage ? 100 : 0,
                    p.waterfront.waterfrontFeet > 0 ? Math.min(100, p.waterfront.waterfrontFeet) : 0
                ],
                borderColor: p.color,
                backgroundColor: p.color + '40',
                pointBackgroundColor: p.color,
                borderWidth: 2
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { stepSize: 25 },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            },
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex].waterfront;
                            return ctx.dataset.label + ': ' + ctx.parsed.r.toFixed(0);
                        }
                    }
                }
            }
        }
    });
}

function createChart_10_4() {
    const ctx = document.getElementById('chart_10_4').getContext('2d');
    
    // Water access type comparison
    const accessTypes = [...new Set(properties.map(p => p.waterfront.waterAccessType))];
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: properties.map(p => p.name + ' - ' + p.waterfront.waterAccessType),
            datasets: [{
                data: properties.map(p => {
                    const typeMap = {
                        'Beach': 10,
                        'Community Dock': 7,
                        'Private Dock': 10,
                        'Boat Ramp': 5,
                        'N/A': 0
                    };
                    return typeMap[p.waterfront.waterAccessType] || 1;
                }),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        generateLabels: (chart) => {
                            const data = chart.data;
                            return data.labels.map((label, i) => ({
                                text: label,
                                fillStyle: data.datasets[0].backgroundColor[i],
                                strokeStyle: data.datasets[0].borderColor[i],
                                lineWidth: 2,
                                hidden: false,
                                index: i
                            }));
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex].waterfront;
                            return [
                                'Access: ' + p.waterAccessType,
                                'Water View: ' + (p.hasWaterView ? 'Yes' : 'No'),
                                'View Type: ' + p.waterViewType
                            ];
                        }
                    }
                }
            }
        }
    });
}

function createChart_10_5() {
    const ctx = document.getElementById('chart_10_5').getContext('2d');
    
    // Price per waterfront foot
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: properties.map(p => p.name),
            datasets: [{
                label: 'Price Per Waterfront Foot',
                data: properties.map(p => p.waterfront.pricePerWaterfrontFt),
                backgroundColor: properties.map(p => p.color + '80'),
                borderColor: properties.map(p => p.color),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => value > 0 ? '$' + value.toLocaleString() : 'N/A'
                    },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const p = properties[ctx.dataIndex];
                            if (ctx.parsed.y === 0) {
                                return 'No Waterfront';
                            }
                            return [
                                'Price/Ft: $' + ctx.parsed.y.toLocaleString(),
                                'Frontage: ' + p.waterfront.waterfrontFeet + ' ft',
                                'Total Price: $' + p.price.toLocaleString()
                            ];
                        }
                    }
                }
            }
        }
    });
}

// =============================================================================
// INITIALIZATION - Initialize all charts on page load
// =============================================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('Property Visualization Dashboard - Initializing...');
    console.log('CONVERSATION ID: PROPERTY-VIZ-SESSION-001');
    console.log('Loading ' + properties.length + ' properties...');
    
    // Category 1
    createChart_1_1();
    createChart_1_2();
    createChart_1_3();
    createChart_1_4();
    createChart_1_5();
    
    // Category 2
    createChart_2_1();
    createChart_2_2();
    createChart_2_3();
    createChart_2_4();
    createChart_2_5();
    
    // Category 3
    createChart_3_1();
    createChart_3_2();
    createChart_3_3();
    createChart_3_4();
    createChart_3_5();
    
    // Category 4
    createChart_4_1();
    createChart_4_2();
    createChart_4_3();
    createChart_4_4();
    createChart_4_5();
    
    // Category 5
    createChart_5_1();
    createChart_5_2();
    createChart_5_3();
    createChart_5_4();
    createChart_5_5();
    
    // Category 6 - BATCH 2
    createChart_6_1();
    createChart_6_2();
    createChart_6_3();
    createChart_6_4();
    createChart_6_5();
    
    // Category 7 - BATCH 2
    createChart_7_1();
    createChart_7_2();
    createChart_7_3();
    createChart_7_4();
    createChart_7_5();
    
    // Category 8 - BATCH 2
    createChart_8_1();
    createChart_8_2();
    createChart_8_3();
    createChart_8_4();
    createChart_8_5();
    
    // Category 9 - BATCH 2
    createChart_9_1();
    createChart_9_2();
    createChart_9_3();
    createChart_9_4();
    createChart_9_5();
    
    // Category 10 - BATCH 2
    createChart_10_1();
    createChart_10_2();
    createChart_10_3();
    createChart_10_4();
    createChart_10_5();
    
    console.log('✅ All 50 visualizations loaded successfully!');
    console.log('📊 Batch 2 (Categories 6-10) complete!');
});
