# Perplexity ↔ Gemini Crash Fix (Turnkey Patch Pack v2)

This zip contains **full replacement files** (not diffs) for the parts of your 3‑property comparison pipeline that were causing:
- Perplexity returning output that failed JSON parsing (especially when nested objects appear)
- Gemini being temporarily disabled / blocking the Tier 4 cascade
- Gemini confidence being forced to Low in arbitration
- Tier naming confusion (Tier 3.5 vs Tier 4) without breaking existing imports

## What changed

### 1) `api/property/search.ts`
- Removes the `if (false)` / hard-disable pattern and replaces it with a request flag:
  - `disableGemini` (default `false`)
- Makes Perplexity JSON parsing robust:
  - strips ```json fences
  - extracts the **first balanced JSON object** when the response includes extra text
- Keeps your existing 5 Perplexity micro-prompts and preserves cascade order.
- Adds stable mapping from numeric Gemini field IDs → your `NN_field_key` schema keys.

### 2) `api/property/arbitration.ts` (and `src/lib/arbitration.ts`)
- Fixes LLM tier fallback: Perplexity remains Tier 4; other LLMs fallback to Tier 5.
- Stops hardcoding Gemini confidence to `Low` when it's explicitly web-grounded:
  - `Gemini 2.0 Search` now returns `Medium` confidence (unless you later choose to raise it)
- Tracks LLM quorum/conflicts for **Tier 4 and Tier 5**, not just Tier 4.

### 3) `src/services/valuation/geminiConfig.ts`
- Adds backwards-compatible aliases so you can migrate naming cleanly:
  - `TIER_4_GEMINI_FIELDS` → alias of `TIER_35_FIELDS`
  - `TIER_4_GEMINI_FIELD_IDS` → alias of `TIER_35_FIELD_IDS`

## How to apply

Replace these files in your repo (paths must match your project):

- `api/property/search.ts`
- `api/property/arbitration.ts` (and/or `src/lib/arbitration.ts` depending on which one your build uses)
- `src/services/valuation/geminiConfig.ts`

The other files included are unchanged and provided only for context.

## Runtime knobs

### Disable Gemini for a request
Send in request body:
```json
{ "disableGemini": true }
```

### Perplexity model selection
Set:
- `PERPLEXITY_MODEL=sonar-pro` (recommended default), or your preferred model.

## Quick sanity checks

1. Deploy to Vercel
2. Confirm server logs contain:
   - `TIER 4: Gemini Structured Search - RUNNING` (or SKIPPED if disabled)
   - `✅ [Perplexity <prompt>] Parsed ... raw fields`
   - `✅ [Perplexity <prompt>] Returning ... fields after filtering`

If you still see old log lines, the deployment is not using the updated build (wrong branch / cached build / wrong project).
