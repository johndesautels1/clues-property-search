# OLIVIA MULTI-LLM PROMPT LIBRARY
## Complete Production-Ready Prompt System for 168-Field Property Analysis

**Version**: 1.0  
**Created**: December 2025  
**For**: John E. Desautels & Associates - CLUES™ Platform  
**Purpose**: Multi-LLM consensus property analysis system

---

## 📚 LIBRARY OVERVIEW

This library contains **200 production-grade prompts** designed to analyze properties across 168 fields and generate comprehensive appraisal reports using multiple LLM systems.

### **Total Prompt Count**:
- **40 Base Prompts** (universal structure)
- **160 LLM-Specific Variants** (optimized for Claude, GPT-4, Gemini, Perplexity)
- **Total: 200 Prompts**

### **Variables Calculated**: ~400 across all categories

---

## 🎯 PROMPT CATEGORIES

### **1. INVESTMENT GRADE ANALYSIS** → `01_INVESTMENT_GRADE/`
Calculate overall investment grade and component scores
- **Files**: 5 prompts (1 base + 4 variants)
- **Variables**: 8 (grade, scores, confidence)
- **LLM Usage**: Claude Opus (primary), GPT-4 (validation)

### **2. SECTION ANALYSIS** → `02_SECTION_ANALYSIS/`
Analyze all 22 property sections individually
- **Files**: 110 prompts (22 base + 88 variants)
- **Variables**: ~154 (grades, scores, findings, strengths, concerns)
- **LLM Usage**: Distributed across all LLMs

### **3. KEY FINDINGS EXTRACTION** → `03_KEY_FINDINGS/`
Synthesize top 6-8 critical insights
- **Files**: 5 prompts (1 base + 4 variants)
- **Variables**: ~32 (titles, descriptions, categories, impacts)
- **LLM Usage**: Claude Opus (primary)

### **4. MARKET FORECAST** → `04_MARKET_FORECAST/`
Multi-LLM consensus market analysis
- **Files**: 5 prompts (1 base + 4 variants)
- **Variables**: ~25 (appreciation, trends, risks, opportunities)
- **LLM Usage**: ALL FOUR LLMs for consensus

### **5. PROPERTY RANKINGS** → `05_PROPERTY_RANKINGS/`
Compare and rank multiple properties
- **Files**: 5 prompts (1 base + 4 variants)
- **Variables**: ~15 (ranks, scores, pros, cons)
- **LLM Usage**: Claude Opus (primary)

### **6. DECISION RECOMMENDATIONS** → `06_DECISION_RECOMMENDATIONS/`
Generate buyer-specific recommendations
- **Files**: 15 prompts (3 base + 12 variants)
- **Variables**: ~60 (actions, reasoning, financial analysis, checklists)
- **LLM Usage**: Claude Opus (primary), GPT-4 (financial)

### **7. VERBAL ANALYSIS / HEYGEN SCRIPTS** → `07_VERBAL_ANALYSIS/`
Generate natural language scripts for avatar
- **Files**: 20 prompts (4 base + 16 variants)
- **Variables**: ~10 long-form scripts
- **LLM Usage**: Claude Opus (narrative quality)

### **8. Q&A SYSTEM** → `08_QA_SYSTEM/`
Interactive question answering
- **Files**: 10 prompts (2 base + 8 variants)
- **Variables**: Dynamic (answers, suggestions, field references)
- **LLM Usage**: Claude Sonnet (speed), Opus (complex queries)

### **9. ANTI-HALLUCINATION VALIDATION** → `09_ANTI_HALLUCINATION/`
Verify accuracy and prevent fabrication
- **Files**: 25 prompts (5 base + 20 variants)
- **Variables**: Quality metrics and confidence scores
- **LLM Usage**: All LLMs (cross-validation)

### **10. OUTPUT SCHEMAS** → `10_OUTPUT_SCHEMAS/`
JSON schemas for all outputs
- **Files**: 40 schema files
- **Purpose**: Ensure consistent output format across all LLMs

---

## 🤖 LLM-SPECIFIC OPTIMIZATION

### **Claude (Opus 4, Sonnet 4.5)**
- **Strengths**: Complex reasoning, nuanced analysis, natural language
- **Prompt Style**: Detailed instructions, XML tags, examples, reasoning chains
- **Best For**: Investment grade, key findings, verbal analysis, complex Q&A
- **Output Format**: XML or Markdown with structured JSON

### **GPT-4 (GPT-4 Turbo, GPT-4o)**
- **Strengths**: Structured output, consistency, function calling, speed
- **Prompt Style**: System messages, JSON schemas, concise instructions
- **Best For**: Section analysis, financial calculations, rankings, validation
- **Output Format**: Strict JSON with schema validation

### **Gemini Pro**
- **Strengths**: Multimodal analysis, fast inference, good at patterns
- **Prompt Style**: Clear hierarchies, bullet points, visual structure
- **Best For**: Section analysis, data extraction, pattern recognition
- **Output Format**: JSON with clear hierarchies

### **Perplexity**
- **Strengths**: Real-time data, web research, citations, market data
- **Prompt Style**: Research-focused, citation requirements, source validation
- **Best For**: Market forecast, current data validation, trend analysis
- **Output Format**: JSON with source citations

---

## 📋 USING THIS LIBRARY

### **Step 1: Choose Your Analysis Type**
Navigate to the appropriate category folder (01-09)

### **Step 2: Select LLM Variant**
Each folder contains:
- `BASE_PROMPT.md` - Universal version
- `CLAUDE_VARIANT.md` - Optimized for Claude
- `GPT4_VARIANT.md` - Optimized for GPT-4
- `GEMINI_VARIANT.md` - Optimized for Gemini
- `PERPLEXITY_VARIANT.md` - Optimized for Perplexity

### **Step 3: Load Property Data**
All prompts expect the same input format:
```json
{
  "property": {
    // 168 fields from OliviaEnhancedPropertyInput
  },
  "context": {
    "buyerProfile": "investor|family|retiree",
    "comparisonProperties": [...] // optional
  }
}
```

### **Step 4: Execute Prompt**
Send to appropriate LLM API with variant-specific configuration

### **Step 5: Parse Response**
All responses follow schemas in `10_OUTPUT_SCHEMAS/`

### **Step 6: Validate**
Use anti-hallucination prompts to verify accuracy

---

## 🔒 ANTI-HALLUCINATION PROTOCOLS

Every prompt includes:
1. **Field Citation Requirements** - Must cite field numbers
2. **Confidence Scoring** - Every metric includes confidence level
3. **Data Completeness Checks** - Flag missing or incomplete data
4. **Cross-Validation** - Compare against other LLM outputs
5. **Hallucination Detection** - Identify fabricated data

**See**: `09_ANTI_HALLUCINATION/` for full validation suite

---

## 🎯 RECOMMENDED LLM ASSIGNMENT

| Task | Primary LLM | Secondary (Validation) | Reason |
|------|-------------|------------------------|--------|
| Investment Grade | Claude Opus | GPT-4 | Complex reasoning needed |
| Section 1-10 | Claude Sonnet | Gemini Pro | Speed + quality balance |
| Section 11-22 | Claude Sonnet | Gemini Pro | Speed + quality balance |
| Key Findings | Claude Opus | - | Synthesis expertise |
| Market Forecast | ALL FOUR | - | Multi-LLM consensus |
| Rankings | Claude Opus | GPT-4 | Comparative analysis |
| Recommendations | Claude Opus | GPT-4 | Financial + reasoning |
| Verbal Scripts | Claude Opus | - | Natural language quality |
| Q&A (Simple) | Claude Sonnet | - | Speed |
| Q&A (Complex) | Claude Opus | - | Deep reasoning |
| Validation | ALL FOUR | - | Cross-validation |

---

## 💰 ESTIMATED API COSTS (Per Analysis)

Based on 3 properties, full analysis:

| LLM | Usage | Est. Tokens | Est. Cost |
|-----|-------|-------------|-----------|
| Claude Opus | Primary analysis | 150K | $2.25 |
| Claude Sonnet | Section analysis | 100K | $0.30 |
| GPT-4 | Validation | 80K | $0.80 |
| Gemini Pro | Section analysis | 80K | $0.08 |
| Perplexity | Market data | 50K | $0.50 |
| **TOTAL** | | **460K** | **$3.93** |

*Prices as of Dec 2025, may vary*

---

## 🚀 QUICK START

### **Single Property Analysis**
1. Load property data (168 fields)
2. Run Investment Grade prompt (Claude Opus)
3. Run all 22 Section prompts (distributed)
4. Run Key Findings prompt (Claude Opus)
5. Run Market Forecast (all 4 LLMs)
6. Synthesize results

### **Multi-Property Comparison**
1. Follow single property steps for each
2. Run Property Rankings prompt (Claude Opus)
3. Run Decision Recommendations (Claude Opus)

### **Generate HeyGen Script**
1. Complete analysis first
2. Run Verbal Analysis prompts (Claude Opus)
3. Format for HeyGen API

---

## 📞 SUPPORT & UPDATES

**Created by**: Claude Sonnet 4.5 for John E. Desautels & Associates  
**Last Updated**: December 15, 2025  
**Version Control**: Track all prompt modifications  
**Testing**: Always validate new prompts with real data before production

---

## 🎓 BEST PRACTICES

1. **Always cite field numbers** in analysis
2. **Include confidence scores** for every metric
3. **Flag missing data** explicitly
4. **Use consistent JSON schemas** for parsing
5. **Cross-validate** critical metrics across LLMs
6. **Version control** all prompt modifications
7. **Test thoroughly** before production deployment
8. **Monitor costs** and optimize LLM assignment
9. **Update prompts** based on real-world performance
10. **Document edge cases** and refinements

---

## 📂 FILE STRUCTURE

```
OLIVIA_PROMPTS/
├── 00_MASTER_INDEX.md (this file)
├── 01_INVESTMENT_GRADE/
│   ├── BASE_PROMPT.md
│   ├── CLAUDE_VARIANT.md
│   ├── GPT4_VARIANT.md
│   ├── GEMINI_VARIANT.md
│   └── PERPLEXITY_VARIANT.md
├── 02_SECTION_ANALYSIS/
│   ├── SECTION_01_ADDRESS_IDENTITY/
│   │   ├── BASE_PROMPT.md
│   │   ├── CLAUDE_VARIANT.md
│   │   ├── GPT4_VARIANT.md
│   │   ├── GEMINI_VARIANT.md
│   │   └── PERPLEXITY_VARIANT.md
│   ├── SECTION_02_PRICING_VALUE/
│   │   └── ... (5 files each)
│   └── ... (22 sections total)
├── 03_KEY_FINDINGS/
├── 04_MARKET_FORECAST/
├── 05_PROPERTY_RANKINGS/
├── 06_DECISION_RECOMMENDATIONS/
│   ├── INVESTOR_PROFILE/
│   ├── FAMILY_PROFILE/
│   └── RETIREE_PROFILE/
├── 07_VERBAL_ANALYSIS/
│   ├── EXECUTIVE_SUMMARY/
│   ├── PROPERTY_ANALYSIS/
│   ├── COMPARISON_INSIGHTS/
│   └── TOP_RECOMMENDATION/
├── 08_QA_SYSTEM/
│   ├── ANSWER_GENERATION/
│   └── QUESTION_SUGGESTIONS/
├── 09_ANTI_HALLUCINATION/
│   ├── FIELD_VALIDATION/
│   ├── CONFIDENCE_SCORING/
│   ├── DATA_COMPLETENESS/
│   ├── CROSS_VALIDATION/
│   └── HALLUCINATION_DETECTION/
└── 10_OUTPUT_SCHEMAS/
    ├── investment_grade_schema.json
    ├── section_analysis_schema.json
    └── ... (40 schemas total)
```

---

**Ready to build world-class AI-powered property analysis? Let's go! 🚀**
